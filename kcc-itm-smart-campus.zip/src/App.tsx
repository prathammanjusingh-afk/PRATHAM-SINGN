/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { ToastContainer } from './components/Toast';
import { EmergencyModal } from './components/EmergencyModal';
import { CampusAIChat } from './components/CampusAIChat';

// Views
import { LandingPage } from './views/LandingPage';
import { AuthView } from './views/AuthView';
import { StudentDashboard } from './views/StudentDashboard';
import { TimetableScheduleView } from './views/TimetableScheduleView';
import { AttendanceDashboardView } from './views/AttendanceDashboardView';
import { CampusMapView } from './views/CampusMapView';
import { EventsHubView } from './views/EventsHubView';
import { AssignmentsView } from './views/AssignmentsView';
import { ComplaintsView } from './views/ComplaintsView';
import { LostFoundView } from './views/LostFoundView';
import { EmergencyView } from './views/EmergencyView';
import { CampusIntelligenceView } from './views/CampusIntelligenceView';
import { AdminDashboardView } from './views/AdminDashboardView';

import {
  LayoutDashboard,
  CalendarDays,
  CheckCheck,
  AlertTriangle,
  Compass,
} from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { activeTab, setActiveTab, currentUser, triggerSosBroadcast } = useApp();
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // If viewing public landing page
  if (activeTab === 'landing') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-sans selection:bg-blue-600 selection:text-white transition-colors">
        <Navbar
          isMobileSidebarOpen={isMobileSidebarOpen}
          onToggleMobileSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
        />
        <LandingPage />
        <CampusAIChat />
        <EmergencyModal />
        <ToastContainer />
      </div>
    );
  }

  // If viewing Auth page
  if (activeTab === 'auth') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-sans selection:bg-blue-600 selection:text-white transition-colors">
        <Navbar
          isMobileSidebarOpen={isMobileSidebarOpen}
          onToggleMobileSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
        />
        <AuthView />
        <CampusAIChat />
        <EmergencyModal />
        <ToastContainer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-sans text-slate-900 dark:text-slate-100 selection:bg-blue-600 selection:text-white flex flex-col transition-colors">
      {/* Top Bar Contract Compliant Navigation Header */}
      <Navbar
        isMobileSidebarOpen={isMobileSidebarOpen}
        onToggleMobileSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
      />

      <div className="flex-1 flex max-w-[1600px] w-full mx-auto">
        {/* Desktop & Mobile Responsive Sidebar */}
        <Sidebar
          isOpen={isMobileSidebarOpen}
          onClose={() => setIsMobileSidebarOpen(false)}
        />

        {/* Main Content Area */}
        <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {activeTab === 'dashboard' && <StudentDashboard />}
          {activeTab === 'timetable' && <TimetableScheduleView />}
          {activeTab === 'attendance' && <AttendanceDashboardView />}
          {activeTab === 'map' && <CampusMapView />}
          {activeTab === 'events' && <EventsHubView />}
          {activeTab === 'assignments' && <AssignmentsView />}
          {activeTab === 'complaints' && <ComplaintsView />}
          {activeTab === 'lostfound' && <LostFoundView />}
          {activeTab === 'emergency' && <EmergencyView />}
          {activeTab === 'intelligence' && <CampusIntelligenceView />}
          {activeTab === 'admin' && <AdminDashboardView />}
        </main>
      </div>

      {/* Mobile Bottom Quick Navigation Bar (Sticky capped <= 15% viewport height) */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-30 h-14 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 flex items-center justify-around px-2 text-[10px] font-semibold text-slate-500">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center gap-1 py-1 px-2 ${
            activeTab === 'dashboard' ? 'text-blue-600 dark:text-cyan-400 font-bold' : ''
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Dashboard</span>
        </button>

        <button
          onClick={() => setActiveTab('timetable')}
          className={`flex flex-col items-center gap-1 py-1 px-2 ${
            activeTab === 'timetable' ? 'text-blue-600 dark:text-cyan-400 font-bold' : ''
          }`}
        >
          <CalendarDays className="w-4 h-4" />
          <span>Schedule</span>
        </button>

        <button
          onClick={() => setActiveTab('attendance')}
          className={`flex flex-col items-center gap-1 py-1 px-2 ${
            activeTab === 'attendance' ? 'text-blue-600 dark:text-cyan-400 font-bold' : ''
          }`}
        >
          <CheckCheck className="w-4 h-4" />
          <span>Attendance</span>
        </button>

        <button
          onClick={() => setActiveTab('map')}
          className={`flex flex-col items-center gap-1 py-1 px-2 ${
            activeTab === 'map' ? 'text-blue-600 dark:text-cyan-400 font-bold' : ''
          }`}
        >
          <Compass className="w-4 h-4" />
          <span>Map</span>
        </button>

        <button
          onClick={triggerSosBroadcast}
          className="flex flex-col items-center gap-1 py-1 px-2 text-rose-600 dark:text-rose-400"
        >
          <AlertTriangle className="w-4 h-4 animate-pulse" />
          <span>SOS</span>
        </button>
      </div>

      {/* Floating KCC CampusAI Assistant */}
      <CampusAIChat />

      {/* Priority Emergency SOS Modal */}
      <EmergencyModal />

      {/* Floating Feedback Toasts */}
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
