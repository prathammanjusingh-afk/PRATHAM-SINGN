import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  MapPin,
  Navigation,
  Clock,
  Phone,
  Compass,
  Building,
  CheckCircle2,
  X,
  Search,
  Filter,
  ExternalLink,
} from 'lucide-react';
import { CampusLocation } from '../types';

export const CampusMapView: React.FC = () => {
  const { campusLocations, selectedLocation, setSelectedLocation } = useApp();
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeNavRoute, setActiveNavRoute] = useState<string[] | null>(null);

  const categories = ['All', 'Academic', 'Labs', 'Library', 'Hostel', 'Cafeteria', 'Sports', 'Medical', 'Security'];

  const filteredLocations = campusLocations.filter(loc => {
    const matchesCat = activeCategory === 'All' || loc.category === activeCategory;
    const matchesSearch =
      loc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loc.building.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loc.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleStartNav = (loc: CampusLocation) => {
    setSelectedLocation(loc);
    setActiveNavRoute(loc.directions);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <Compass className="w-6 h-6 text-blue-600 dark:text-cyan-400" />
            <span>KCC Digital Campus Map</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Interactive geographical positioning & navigation across Greater Noida campus
          </p>
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-72">
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search blocks, labs, library..."
            className="w-full pl-9 pr-4 py-2 rounded-xl text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap transition-colors ${
              activeCategory === cat
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Main Grid: Interactive Map Canvas + Location Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Map Canvas (SVG / Architectural Plan) */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col">
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 bg-slate-50/50 dark:bg-slate-850">
            <span className="font-semibold text-slate-800 dark:text-slate-200">
              KCC ITM Campus Master Layout (Knowledge Park III)
            </span>
            <span className="font-mono text-[11px]">Click any pinpoint marker</span>
          </div>

          <div className="relative w-full aspect-[16/10] bg-gradient-to-br from-slate-100 via-blue-50/40 to-slate-200 dark:from-slate-950 dark:via-blue-950/20 dark:to-slate-900 overflow-hidden flex items-center justify-center p-4">
            {/* Campus Architectural Floor Grid Background */}
            <svg
              className="absolute inset-0 w-full h-full text-slate-300/40 dark:text-slate-800/60 pointer-events-none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <pattern id="grid-pattern" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid-pattern)" />

              {/* Campus Roads / Walkways */}
              <path
                d="M 150 500 L 150 200 L 450 200 L 450 500 Z"
                fill="none"
                stroke="rgba(59, 130, 246, 0.2)"
                strokeWidth="24"
                strokeLinejoin="round"
              />
              <path
                d="M 150 350 L 750 350"
                fill="none"
                stroke="rgba(59, 130, 246, 0.2)"
                strokeWidth="20"
              />
              <circle cx="450" cy="350" r="45" fill="rgba(6, 182, 212, 0.15)" stroke="rgba(6, 182, 212, 0.4)" strokeWidth="2" />
            </svg>

            {/* Central Landmark Labels on Canvas */}
            <div className="absolute bottom-3 left-3 text-[10px] font-mono text-slate-400 bg-white/80 dark:bg-slate-900/80 px-2 py-1 rounded border border-slate-200 dark:border-slate-800 pointer-events-none">
              Main Entrance: Knowledge Park III Road ➔
            </div>

            {/* Interactive Pins */}
            {filteredLocations.map(loc => {
              const isSelected = selectedLocation?.id === loc.id;
              return (
                <button
                  key={loc.id}
                  onClick={() => {
                    setSelectedLocation(loc);
                    setActiveNavRoute(null);
                  }}
                  style={{
                    left: `${loc.position.x}%`,
                    top: `${loc.position.y}%`,
                  }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 group focus:outline-none transition-all z-20 ${
                    isSelected ? 'scale-125 z-30' : 'hover:scale-110'
                  }`}
                >
                  <div
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full font-bold text-[11px] shadow-lg transition-all ${
                      isSelected
                        ? 'bg-blue-600 text-white ring-4 ring-blue-400/40 shadow-blue-600/30'
                        : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 hover:border-blue-400'
                    }`}
                  >
                    <MapPin className={`w-3.5 h-3.5 ${isSelected ? 'text-white' : 'text-blue-600 dark:text-cyan-400'}`} />
                    <span className="hidden sm:inline whitespace-nowrap">{loc.name.split(' ')[0]}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Location Details & Navigation Drawer */}
        <div className="lg:col-span-4 space-y-4">
          {selectedLocation ? (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-blue-600 dark:text-cyan-400 px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800">
                    {selectedLocation.category}
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-1.5">
                    {selectedLocation.name}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {selectedLocation.building} · {selectedLocation.floor}
                  </p>
                </div>
                <button
                  onClick={() => {
                    setSelectedLocation(null);
                    setActiveNavRoute(null);
                  }}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {selectedLocation.description}
              </p>

              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                  <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{selectedLocation.openingHours}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                  <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{selectedLocation.contact}</span>
                </div>
              </div>

              {/* Facilities tags */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                <span className="text-[11px] font-semibold text-slate-400 block mb-2">
                  Facilities Available:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {selectedLocation.facilities.map((fac, idx) => (
                    <span
                      key={idx}
                      className="text-[11px] text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md"
                    >
                      {fac}
                    </span>
                  ))}
                </div>
              </div>

              {/* Navigation Action Button */}
              <div className="pt-2">
                <button
                  onClick={() => handleStartNav(selectedLocation)}
                  className="w-full py-2.5 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-2"
                >
                  <Navigation className="w-4 h-4" />
                  <span>Navigate Here (Step-by-Step)</span>
                </button>
              </div>

              {/* Step-by-Step Directions */}
              {activeNavRoute && (
                <div className="mt-4 p-4 rounded-xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 space-y-2">
                  <span className="text-xs font-bold text-blue-900 dark:text-cyan-300 block">
                    Walking Route Guide (Est. ~2-3 mins):
                  </span>
                  <ol className="space-y-1.5 text-xs text-slate-700 dark:text-slate-200">
                    {activeNavRoute.map((step, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="font-bold text-blue-600 dark:text-cyan-400 font-mono">
                          {idx + 1}.
                        </span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm text-center">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-cyan-400 flex items-center justify-center mx-auto mb-3">
                <Building className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Select a Campus Landmark
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Choose any facility from the map canvas or search by name to view hours, lab capacity, and walking directions.
              </p>
            </div>
          )}

          {/* Quick List of Nearby Landmarks */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 px-2 block mb-2">
              Directory Locations ({filteredLocations.length})
            </span>
            <div className="space-y-1 max-h-60 overflow-y-auto">
              {filteredLocations.map(loc => (
                <button
                  key={loc.id}
                  onClick={() => {
                    setSelectedLocation(loc);
                    setActiveNavRoute(null);
                  }}
                  className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs transition-colors text-left ${
                    selectedLocation?.id === loc.id
                      ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-cyan-300 font-bold'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <div>
                    <p className="font-semibold">{loc.name}</p>
                    <p className="text-[10px] text-slate-400">{loc.building}</p>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{loc.category}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
