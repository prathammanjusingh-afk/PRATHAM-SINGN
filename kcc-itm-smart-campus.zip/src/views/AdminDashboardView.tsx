import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Shield,
  Users,
  CalendarDays,
  Calendar,
  AlertCircle,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Bell,
  Wrench,
  Search,
  Filter,
  BarChart3,
  X,
} from 'lucide-react';
import { TimetableClass, SpecialClass, HolidayOrNoClass, Notice, Complaint } from '../types';

export const AdminDashboardView: React.FC = () => {
  const {
    currentUser,
    timetable,
    specialClasses,
    holidays,
    addTimetableClass,
    deleteTimetableClass,
    addSpecialClass,
    deleteSpecialClass,
    addHoliday,
    deleteHoliday,
    students,
    updateStudentStatus,
    notices,
    addNotice,
    deleteNotice,
    complaints,
    updateComplaintStatus,
  } = useApp();

  const [adminTab, setAdminTab] = useState<'overview' | 'timetable' | 'students' | 'notices' | 'complaints'>('overview');

  // Timetable Add Modal State
  const [isAddClassModalOpen, setIsAddClassModalOpen] = useState(false);
  const [newClassDay, setNewClassDay] = useState<number>(1);
  const [newClassCode, setNewClassCode] = useState('CS512');
  const [newClassName, setNewClassName] = useState('Network Security & Cryptography');
  const [newClassFaculty, setNewClassFaculty] = useState('Dr. Priya Verma');
  const [newClassRoom, setNewClassRoom] = useState('LH-205');
  const [newClassBuilding, setNewClassBuilding] = useState('Academic Block A');
  const [newClassStart, setNewClassStart] = useState('16:00');
  const [newClassEnd, setNewClassEnd] = useState('17:00');
  const [newClassType, setNewClassType] = useState<'lecture' | 'lab' | 'tutorial'>('lecture');

  // Special Class Modal State
  const [isSpecialModalOpen, setIsSpecialModalOpen] = useState(false);
  const [specialDate, setSpecialDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [specialSubject, setSpecialSubject] = useState('Extra Python AI Hands-on Workshop');
  const [specialFaculty, setSpecialFaculty] = useState('Prof. Rajesh Sharma');
  const [specialRoom, setSpecialRoom] = useState('Lab 3');
  const [specialStart, setSpecialStart] = useState('16:30');
  const [specialEnd, setSpecialEnd] = useState('18:00');
  const [specialReason, setSpecialReason] = useState('Syllabus revision & project mentoring');

  // Holiday Modal State
  const [isHolidayModalOpen, setIsHolidayModalOpen] = useState(false);
  const [holidayDate, setHolidayDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [holidayName, setHolidayName] = useState('Semester Break / Institutional Recess');
  const [holidayType, setHolidayType] = useState<HolidayOrNoClass['type']>('holiday');
  const [holidayDesc, setHolidayDesc] = useState('All academic classes cancelled for the day.');

  // Notice Add State
  const [isNoticeModalOpen, setIsNoticeModalOpen] = useState(false);
  const [noticeTitle, setNoticeTitle] = useState('');
  const [noticeContent, setNoticeContent] = useState('');
  const [noticeCategory, setNoticeCategory] = useState<Notice['category']>('Academic');
  const [noticePriority, setNoticePriority] = useState<Notice['priority']>('High');

  // Student Search
  const [studentSearch, setStudentSearch] = useState('');

  const filteredStudents = students.filter(
    s =>
      s.name.toLowerCase().includes(studentSearch.toLowerCase()) ||
      s.studentId.toLowerCase().includes(studentSearch.toLowerCase()) ||
      s.department.toLowerCase().includes(studentSearch.toLowerCase())
  );

  const handleCreateClass = (e: React.FormEvent) => {
    e.preventDefault();
    addTimetableClass({
      dayOfWeek: Number(newClassDay),
      subjectCode: newClassCode,
      subjectName: newClassName,
      facultyName: newClassFaculty,
      room: newClassRoom,
      building: newClassBuilding,
      startTime: newClassStart,
      endTime: newClassEnd,
      type: newClassType,
    });
    setIsAddClassModalOpen(false);
  };

  const handleCreateSpecial = (e: React.FormEvent) => {
    e.preventDefault();
    addSpecialClass({
      dateStr: specialDate,
      subjectCode: 'SP-EXTRA',
      subjectName: specialSubject,
      facultyName: specialFaculty,
      room: specialRoom,
      building: 'Academic Block B',
      startTime: specialStart,
      endTime: specialEnd,
      type: 'lecture',
      reason: specialReason,
    });
    setIsSpecialModalOpen(false);
  };

  const handleCreateHoliday = (e: React.FormEvent) => {
    e.preventDefault();
    addHoliday({
      dateStr: holidayDate,
      name: holidayName,
      type: holidayType,
      description: holidayDesc,
    });
    setIsHolidayModalOpen(false);
  };

  const handleCreateNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noticeTitle.trim() || !noticeContent.trim()) return;

    addNotice({
      title: noticeTitle,
      content: noticeContent,
      category: noticeCategory,
      priority: noticePriority,
      publishedBy: currentUser?.name || 'Dean of Academic Affairs',
    });

    setIsNoticeModalOpen(false);
    setNoticeTitle('');
    setNoticeContent('');
  };

  const daysMap = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 text-[10px] font-bold uppercase tracking-wider mb-1">
            <Shield className="w-3.5 h-3.5" />
            <span>Administrator Control Hub</span>
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Institutional Administration & Governance
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            KCC Institute of Technology & Management · Directorate of Systems & Academics
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl overflow-x-auto">
          {(
            [
              { id: 'overview', label: 'Overview' },
              { id: 'timetable', label: 'Timetable Manager' },
              { id: 'students', label: 'Students' },
              { id: 'notices', label: 'Notices' },
              { id: 'complaints', label: 'Complaints' },
            ] as const
          ).map(tab => (
            <button
              key={tab.id}
              onClick={() => setAdminTab(tab.id)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
                adminTab === tab.id
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* 1. OVERVIEW TAB */}
      {/* ------------------------------------------------------------- */}
      {adminTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Total Enrolled Students
              </span>
              <div className="mt-2 text-3xl font-extrabold font-mono text-slate-900 dark:text-white tabular-nums">
                2,480
              </div>
              <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold mt-1">
                98.4% Active Status
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Average Campus Attendance
              </span>
              <div className="mt-2 text-3xl font-extrabold font-mono text-blue-600 dark:text-cyan-400 tabular-nums">
                81.2%
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Across 14 engineering departments
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Open Maintenance Grievances
              </span>
              <div className="mt-2 text-3xl font-extrabold font-mono text-amber-600 dark:text-amber-400 tabular-nums">
                {complaints.filter(c => c.status !== 'Resolved').length}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Avg turnaround &lt; 2.4 hours
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Weekly Class Load
              </span>
              <div className="mt-2 text-3xl font-extrabold font-mono text-purple-600 dark:text-purple-400 tabular-nums">
                {timetable.length} Classes
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Single source of truth in database
              </p>
            </div>
          </div>

          {/* Quick Admin Actions Box */}
          <div className="p-6 rounded-3xl bg-slate-900 text-white border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-cyan-400 font-mono">
              Quick Administrative Directives
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                onClick={() => {
                  setAdminTab('timetable');
                  setIsHolidayModalOpen(true);
                }}
                className="p-3.5 rounded-2xl bg-white/10 hover:bg-white/20 transition-colors text-left space-y-1"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                  <Calendar className="w-4 h-4" />
                  <span>Mark Holiday / Recess</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Sets scheduled classes to 0 for any date on all student dashboards.
                </p>
              </button>

              <button
                onClick={() => {
                  setAdminTab('timetable');
                  setIsSpecialModalOpen(true);
                }}
                className="p-3.5 rounded-2xl bg-white/10 hover:bg-white/20 transition-colors text-left space-y-1"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-cyan-300">
                  <Plus className="w-4 h-4" />
                  <span>Schedule One-Time Class</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Adds an extra class for a specific date (Normal + Special = Total).
                </p>
              </button>

              <button
                onClick={() => {
                  setAdminTab('notices');
                  setIsNoticeModalOpen(true);
                }}
                className="p-3.5 rounded-2xl bg-white/10 hover:bg-white/20 transition-colors text-left space-y-1"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
                  <Bell className="w-4 h-4" />
                  <span>Broadcast Notice</span>
                </div>
                <p className="text-[11px] text-slate-300">
                  Instantly publish high-priority alerts to student noticeboards.
                </p>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 2. TIMETABLE MANAGER TAB */}
      {/* ------------------------------------------------------------- */}
      {adminTab === 'timetable' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Master Weekly Timetable ({timetable.length} Classes Configured)
                </h3>
                <p className="text-xs text-slate-500">
                  Modifying classes here automatically recalculates the daily class count for all students.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setIsHolidayModalOpen(true)}
                  className="px-3 py-2 rounded-xl text-xs font-semibold bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 hover:bg-amber-100 transition-colors"
                >
                  + Mark Holiday Date
                </button>
                <button
                  onClick={() => setIsSpecialModalOpen(true)}
                  className="px-3 py-2 rounded-xl text-xs font-semibold bg-purple-50 dark:bg-purple-950 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 hover:bg-purple-100 transition-colors"
                >
                  + Add Special Class
                </button>
                <button
                  onClick={() => setIsAddClassModalOpen(true)}
                  className="px-3 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Timetable Class</span>
                </button>
              </div>
            </div>

            {/* Timetable Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-400 bg-slate-50/80 dark:bg-slate-850">
                    <th className="py-3 px-3">Day</th>
                    <th className="py-3 px-3">Time</th>
                    <th className="py-3 px-3">Subject</th>
                    <th className="py-3 px-3">Faculty</th>
                    <th className="py-3 px-3">Location</th>
                    <th className="py-3 px-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {timetable.map(c => (
                    <tr key={c.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-white">
                        {daysMap[c.dayOfWeek]}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-700 dark:text-slate-300">
                        {c.startTime} – {c.endTime}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="font-semibold text-slate-900 dark:text-white block">
                          {c.subjectName}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">
                          {c.subjectCode} · {c.type}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                        {c.facultyName}
                      </td>
                      <td className="py-2.5 px-3 text-slate-500">
                        {c.room} ({c.building})
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          onClick={() => deleteTimetableClass(c.id)}
                          className="p-1 rounded text-rose-500 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                          title="Delete class"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Active Holidays & Special Classes Table */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Holidays List */}
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                  Configured Holidays & No-Class Days
                </h4>
                <span className="text-[11px] text-slate-400 font-mono">{holidays.length} active</span>
              </div>

              <div className="space-y-2">
                {holidays.map(h => (
                  <div
                    key={h.id}
                    className="p-3 rounded-xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 flex items-center justify-between text-xs"
                  >
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">{h.name}</p>
                      <p className="text-[11px] text-slate-500 font-mono">
                        {h.dateStr} · {h.type}
                      </p>
                    </div>
                    <button
                      onClick={() => deleteHoliday(h.id)}
                      className="p-1 text-slate-400 hover:text-rose-600"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Special Classes List */}
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
                  One-Time Special Classes
                </h4>
                <span className="text-[11px] text-slate-400 font-mono">{specialClasses.length} active</span>
              </div>

              <div className="space-y-2">
                {specialClasses.map(s => (
                  <div
                    key={s.id}
                    className="p-3 rounded-xl bg-purple-50/50 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-900/40 flex items-center justify-between text-xs"
                  >
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">{s.subjectName}</p>
                      <p className="text-[11px] text-slate-500">
                        {s.dateStr} · {s.startTime}–{s.endTime} ({s.room})
                      </p>
                    </div>
                    <button
                      onClick={() => deleteSpecialClass(s.id)}
                      className="p-1 text-slate-400 hover:text-rose-600"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 3. STUDENT DIRECTORY TAB */}
      {/* ------------------------------------------------------------- */}
      {adminTab === 'students' && (
        <div className="space-y-4">
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Student Enrollment & Record System ({students.length} Total)
                </h3>
                <p className="text-xs text-slate-500">
                  Search, review attendance records, and manage academic enrollment status
                </p>
              </div>

              <div className="relative w-full sm:w-64">
                <input
                  type="text"
                  value={studentSearch}
                  onChange={e => setStudentSearch(e.target.value)}
                  placeholder="Search by name, roll no, branch..."
                  className="w-full pl-9 pr-3.5 py-1.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-400 bg-slate-50/80 dark:bg-slate-850">
                    <th className="py-3 px-3">Student Name</th>
                    <th className="py-3 px-3">Roll Number</th>
                    <th className="py-3 px-3">Department & Year</th>
                    <th className="py-3 px-3">Attendance %</th>
                    <th className="py-3 px-3">Status</th>
                    <th className="py-3 px-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredStudents.map(student => (
                    <tr key={student.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="py-2.5 px-3">
                        <span className="font-bold text-slate-900 dark:text-white block">
                          {student.name}
                        </span>
                        <span className="text-[11px] text-slate-400">{student.email}</span>
                      </td>
                      <td className="py-2.5 px-3 font-mono font-medium">{student.studentId}</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                        {student.department} · {student.year}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-bold">
                        <span
                          className={
                            student.attendancePercentage >= 75
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-rose-600 dark:text-rose-400'
                          }
                        >
                          {student.attendancePercentage}%
                        </span>
                      </td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            student.status === 'Active'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          }`}
                        >
                          {student.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          onClick={() =>
                            updateStudentStatus(
                              student.id,
                              student.status === 'Active' ? 'On Leave' : 'Active'
                            )
                          }
                          className="text-xs text-blue-600 dark:text-cyan-400 hover:underline font-semibold"
                        >
                          Toggle Status
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 4. NOTICES TAB */}
      {/* ------------------------------------------------------------- */}
      {adminTab === 'notices' && (
        <div className="space-y-4">
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Campus Notices & Directives
                </h3>
                <p className="text-xs text-slate-500">
                  Published across student portals and academic mobile feeds
                </p>
              </div>

              <button
                onClick={() => setIsNoticeModalOpen(true)}
                className="px-3 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Publish Notice</span>
              </button>
            </div>

            <div className="space-y-3">
              {notices.map(notice => (
                <div
                  key={notice.id}
                  className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-850 flex items-start justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                        {notice.category}
                      </span>
                      <span className="text-[10px] text-rose-600 font-bold">
                        {notice.priority} Priority
                      </span>
                      <span className="text-[11px] text-slate-400">· {notice.publishedDate}</span>
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                      {notice.title}
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      {notice.content}
                    </p>
                  </div>

                  <button
                    onClick={() => deleteNotice(notice.id)}
                    className="p-1 text-slate-400 hover:text-rose-600"
                    title="Delete notice"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 5. COMPLAINTS RESOLUTION TAB */}
      {/* ------------------------------------------------------------- */}
      {adminTab === 'complaints' && (
        <div className="space-y-4">
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Grievance Resolution & Staff Dispatch Console
              </h3>
              <p className="text-xs text-slate-500">
                Change status, dispatch facility engineers, and update resolution notes
              </p>
            </div>

            <div className="space-y-3">
              {complaints.map(cmp => (
                <div
                  key={cmp.id}
                  className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3 text-xs"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-blue-600 dark:text-cyan-400">
                        {cmp.ticketId}
                      </span>
                      <span className="font-bold text-slate-900 dark:text-white">
                        {cmp.title}
                      </span>
                      <span className="text-slate-400">({cmp.category})</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-500">Status:</span>
                      <select
                        value={cmp.status}
                        onChange={e => updateComplaintStatus(cmp.id, e.target.value as any)}
                        className="px-2.5 py-1 rounded-lg text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-bold"
                      >
                        <option value="Submitted">Submitted</option>
                        <option value="Assigned">Assigned</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Resolved">Resolved</option>
                      </select>
                    </div>
                  </div>

                  <p className="text-slate-600 dark:text-slate-300">{cmp.description}</p>

                  <div className="flex flex-wrap items-center gap-4 text-[11px] text-slate-400">
                    <span>Student: {cmp.studentName}</span>
                    <span>Location: {cmp.location}</span>
                    <span>Department: {cmp.department}</span>
                    <span>Assigned To: {cmp.assignedTo || 'Unassigned'}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add Timetable Class */}
      {isAddClassModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex justify-between items-start">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Add Class to Master Timetable
              </h3>
              <button onClick={() => setIsAddClassModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleCreateClass} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Day of Week
                  </label>
                  <select
                    value={newClassDay}
                    onChange={e => setNewClassDay(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  >
                    <option value={1}>Monday</option>
                    <option value={2}>Tuesday</option>
                    <option value={3}>Wednesday</option>
                    <option value={4}>Thursday</option>
                    <option value={5}>Friday</option>
                    <option value={6}>Saturday</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Subject Code
                  </label>
                  <input
                    type="text"
                    value={newClassCode}
                    onChange={e => setNewClassCode(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Subject Name
                </label>
                <input
                  type="text"
                  value={newClassName}
                  onChange={e => setNewClassName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Faculty In-Charge
                  </label>
                  <input
                    type="text"
                    value={newClassFaculty}
                    onChange={e => setNewClassFaculty(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Room / Hall
                  </label>
                  <input
                    type="text"
                    value={newClassRoom}
                    onChange={e => setNewClassRoom(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Start Time
                  </label>
                  <input
                    type="time"
                    value={newClassStart}
                    onChange={e => setNewClassStart(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    End Time
                  </label>
                  <input
                    type="time"
                    value={newClassEnd}
                    onChange={e => setNewClassEnd(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddClassModalOpen(false)}
                  className="px-4 py-2 rounded-xl font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Save to Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Schedule Special Class */}
      {isSpecialModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex justify-between items-start">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Add One-Time Special Class
              </h3>
              <button onClick={() => setIsSpecialModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleCreateSpecial} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Date for Special Class
                </label>
                <input
                  type="date"
                  value={specialDate}
                  onChange={e => setSpecialDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Subject / Topic Title
                </label>
                <input
                  type="text"
                  value={specialSubject}
                  onChange={e => setSpecialSubject(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Faculty
                  </label>
                  <input
                    type="text"
                    value={specialFaculty}
                    onChange={e => setSpecialFaculty(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Room
                  </label>
                  <input
                    type="text"
                    value={specialRoom}
                    onChange={e => setSpecialRoom(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsSpecialModalOpen(false)}
                  className="px-4 py-2 rounded-xl font-semibold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold bg-purple-600 hover:bg-purple-700 text-white"
                >
                  Schedule Special Class
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Mark Holiday Date */}
      {isHolidayModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex justify-between items-start">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Mark Holiday / No-Class Day
              </h3>
              <button onClick={() => setIsHolidayModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleCreateHoliday} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Target Date
                </label>
                <input
                  type="date"
                  value={holidayDate}
                  onChange={e => setHolidayDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Holiday / Occasion Title
                </label>
                <input
                  type="text"
                  value={holidayName}
                  onChange={e => setHolidayName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Type of Suspension
                </label>
                <select
                  value={holidayType}
                  onChange={e => setHolidayType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                >
                  <option value="holiday">Official Holiday</option>
                  <option value="college_closed">College Closed</option>
                  <option value="examination">Examination Preparatory Day</option>
                  <option value="campus_event">Campus Event / Tech Fest Day</option>
                  <option value="no_classes">No Regular Classes</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsHolidayModalOpen(false)}
                  className="px-4 py-2 rounded-xl font-semibold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold bg-amber-600 hover:bg-amber-700 text-white"
                >
                  Mark Holiday (Classes = 0)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Publish Notice */}
      {isNoticeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex justify-between items-start">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Publish Official Campus Directive
              </h3>
              <button onClick={() => setIsNoticeModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleCreateNotice} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Notice Title *
                </label>
                <input
                  type="text"
                  value={noticeTitle}
                  onChange={e => setNoticeTitle(e.target.value)}
                  placeholder="e.g. Mandatory 75% Attendance Requirement"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Category
                  </label>
                  <select
                    value={noticeCategory}
                    onChange={e => setNoticeCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  >
                    <option value="Academic">Academic</option>
                    <option value="Examination">Examination</option>
                    <option value="Hostel">Hostel</option>
                    <option value="Events">Events</option>
                    <option value="General">General</option>
                    <option value="Emergency">Emergency</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Priority Level
                  </label>
                  <select
                    value={noticePriority}
                    onChange={e => setNoticePriority(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  >
                    <option value="Normal">Normal</option>
                    <option value="High">High</option>
                    <option value="Urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Content Body *
                </label>
                <textarea
                  value={noticeContent}
                  onChange={e => setNoticeContent(e.target.value)}
                  rows={4}
                  placeholder="Official instructions for students and departments..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsNoticeModalOpen(false)}
                  className="px-4 py-2 rounded-xl font-semibold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Publish to Noticeboard
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
