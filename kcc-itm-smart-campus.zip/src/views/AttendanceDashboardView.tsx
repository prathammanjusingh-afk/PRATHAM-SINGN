import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  CheckCheck,
  Calculator,
  ShieldCheck,
  AlertTriangle,
  AlertOctagon,
  TrendingUp,
  Percent,
  Sliders,
  ChevronRight,
  Info,
} from 'lucide-react';

export const AttendanceDashboardView: React.FC = () => {
  const {
    overallAttendance,
    subjectAttendanceList,
    calculateAttendanceTarget,
    setActiveTab,
  } = useApp();

  const [targetPercentage, setTargetPercentage] = useState<number>(80);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('overall');

  // Find calculations based on selection (Overall or Specific Subject)
  let currentP = overallAttendance.presentCount;
  let currentT = overallAttendance.totalClasses;
  let labelName = 'Overall Campus Aggregate';

  if (selectedSubjectId !== 'overall') {
    const sub = subjectAttendanceList.find(s => s.id === selectedSubjectId);
    if (sub) {
      currentP = sub.presentCount;
      currentT = sub.totalConducted;
      labelName = `${sub.code} · ${sub.name}`;
    }
  }

  const calcResult = calculateAttendanceTarget(targetPercentage, currentP, currentT);

  // Status badge styling
  const statusBadges = {
    Safe: {
      label: 'Safe',
      icon: '🟢',
      class: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800',
    },
    Warning: {
      label: 'Warning',
      icon: '🟡',
      class: 'bg-amber-50 text-amber-700 dark:bg-amber-950/70 dark:text-amber-300 border border-amber-200 dark:border-amber-800',
    },
    Critical: {
      label: 'Critical',
      icon: '🔴',
      class: 'bg-rose-50 text-rose-700 dark:bg-rose-950/70 dark:text-rose-300 border border-rose-200 dark:border-rose-800',
    },
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
          <CheckCheck className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
          <span>Smart Attendance & Predictive Calculator</span>
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Connected to AKTU institutional 75% threshold · Automated subject attendance tracking
        </p>
      </div>

      {/* Top Cards: Overall Metric & Status */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Overall Standing
          </span>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono text-slate-900 dark:text-white tabular-nums">
              {overallAttendance.percentage}%
            </span>
            <span className="text-xs text-emerald-600 dark:text-emerald-400 font-bold">
              {overallAttendance.isSafe ? 'Eligible for Exams' : 'Under Review'}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Mandatory Institutional Threshold: 75.0%
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Total Classes Conducted
          </span>
          <div className="mt-2 text-3xl font-extrabold font-mono text-slate-900 dark:text-white tabular-nums">
            {overallAttendance.totalClasses}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Across 5 core CSE semester subjects
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Classes Attended
          </span>
          <div className="mt-2 text-3xl font-extrabold font-mono text-emerald-600 dark:text-emerald-400 tabular-nums">
            {overallAttendance.presentCount}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Verified by lecture bio-scanners
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Classes Missed
          </span>
          <div className="mt-2 text-3xl font-extrabold font-mono text-rose-600 dark:text-rose-400 tabular-nums">
            {overallAttendance.absentCount}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Includes excused medical leave
          </p>
        </div>
      </div>

      {/* SMART ATTENDANCE CALCULATOR WIDGET */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-blue-900 via-indigo-950 to-slate-900 text-white relative overflow-hidden shadow-xl border border-blue-400/30">
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Controls column */}
          <div className="lg:col-span-6 space-y-4">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-white/10 backdrop-blur-md">
                <Calculator className="w-5 h-5 text-cyan-400" />
              </div>
              <div>
                <h2 className="text-lg font-bold">Smart Attendance Calculator</h2>
                <p className="text-xs text-blue-200">
                  Predictive simulation for exam eligibility & attendance optimization
                </p>
              </div>
            </div>

            {/* Subject Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Target Subject / Aggregate
              </label>
              <select
                value={selectedSubjectId}
                onChange={e => setSelectedSubjectId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-900/80 border border-white/20 text-white focus:outline-none focus:ring-2 focus:ring-cyan-400"
              >
                <option value="overall">Overall Campus Aggregate (Current: {overallAttendance.percentage}%)</option>
                {subjectAttendanceList.map(s => (
                  <option key={s.id} value={s.id}>
                    {s.code} · {s.name} (Current: {s.percentage}%)
                  </option>
                ))}
              </select>
            </div>

            {/* Target Percentage Slider */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-semibold text-slate-300">Desired Attendance Target</span>
                <span className="font-mono font-extrabold text-cyan-400 text-base">{targetPercentage}%</span>
              </div>
              <input
                type="range"
                min="60"
                max="95"
                step="1"
                value={targetPercentage}
                onChange={e => setTargetPercentage(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>60%</span>
                <span className="text-amber-400 font-bold">75% (AKTU Minimum)</span>
                <span>80%</span>
                <span>85%</span>
                <span>95%</span>
              </div>
            </div>

            {/* Quick Presets */}
            <div className="flex items-center gap-2 pt-1">
              <span className="text-[11px] text-slate-300">Quick Targets:</span>
              {[75, 80, 85, 90].map(val => (
                <button
                  key={val}
                  onClick={() => setTargetPercentage(val)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono font-semibold transition-colors ${
                    targetPercentage === val
                      ? 'bg-cyan-400 text-slate-950 font-bold'
                      : 'bg-white/10 hover:bg-white/20 text-white'
                  }`}
                >
                  {val}%
                </button>
              ))}
            </div>
          </div>

          {/* Results column */}
          <div className="lg:col-span-6 bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 space-y-4">
            <span className="text-[11px] font-mono text-cyan-300 font-bold uppercase tracking-wider block">
              Prediction for {labelName}
            </span>

            <div className="flex items-baseline justify-between border-b border-white/10 pb-3">
              <span className="text-xs text-slate-300">Current Standing:</span>
              <span className="text-lg font-bold font-mono text-white">
                {calcResult.currentPct}% ({currentP} / {currentT} classes)
              </span>
            </div>

            {/* Actionable Prediction Cards */}
            {calcResult.currentPct < targetPercentage ? (
              <div className="p-4 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-100 space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>Consecutive Attendance Required</span>
                </div>
                <p className="text-sm font-extrabold text-white">
                  You need to attend{' '}
                  <span className="text-cyan-300 text-lg font-mono underline decoration-2">
                    {calcResult.neededConsecutive} consecutive classes
                  </span>{' '}
                  to reach {targetPercentage}%.
                </p>
                <p className="text-[11px] text-amber-200">
                  Do not miss any further lectures until your target percentage is secured.
                </p>
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-100 space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
                  <ShieldCheck className="w-4 h-4 shrink-0" />
                  <span>Above Target Margin</span>
                </div>
                <p className="text-sm font-extrabold text-white">
                  You can miss{' '}
                  <span className="text-emerald-300 text-lg font-mono underline decoration-2">
                    {calcResult.canMiss} classes
                  </span>{' '}
                  while remaining above {targetPercentage}%.
                </p>
                <p className="text-[11px] text-emerald-200">
                  Your safety buffer is strong. Maintain regular attendance for optimal internal marks.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* SUBJECT-WISE ATTENDANCE TABLE */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Subject-Wise Attendance Breakdown
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Department of Computer Science & Engineering · Semester V
            </p>
          </div>
          <span className="text-xs text-slate-500">
            Threshold: <strong className="text-slate-900 dark:text-white">75%</strong>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-400 bg-slate-50/80 dark:bg-slate-850">
                <th className="py-3 px-4">Subject & Code</th>
                <th className="py-3 px-4">Faculty In-Charge</th>
                <th className="py-3 px-4 text-center">Conducted</th>
                <th className="py-3 px-4 text-center">Present</th>
                <th className="py-3 px-4 text-center">Absent</th>
                <th className="py-3 px-4">Attendance %</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {subjectAttendanceList.map(sub => (
                <tr key={sub.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                  <td className="py-3.5 px-4">
                    <span className="font-bold text-slate-900 dark:text-white block">
                      {sub.name}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">
                      {sub.code}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                    {sub.faculty}
                  </td>
                  <td className="py-3.5 px-4 text-center font-mono font-medium text-slate-800 dark:text-slate-200 tabular-nums">
                    {sub.totalConducted}
                  </td>
                  <td className="py-3.5 px-4 text-center font-mono font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                    {sub.presentCount}
                  </td>
                  <td className="py-3.5 px-4 text-center font-mono font-bold text-rose-600 dark:text-rose-400 tabular-nums">
                    {sub.absentCount}
                  </td>
                  <td className="py-3.5 px-4 w-48">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            sub.status === 'Safe'
                              ? 'bg-emerald-500'
                              : sub.status === 'Warning'
                              ? 'bg-amber-500'
                              : 'bg-rose-500'
                          }`}
                          style={{ width: `${Math.min(sub.percentage, 100)}%` }}
                        />
                      </div>
                      <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                        {sub.percentage}%
                      </span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-center whitespace-nowrap">
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[11px] font-bold ${
                        statusBadges[sub.status].class
                      }`}
                    >
                      <span>{statusBadges[sub.status].icon}</span>
                      <span>{statusBadges[sub.status].label}</span>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
