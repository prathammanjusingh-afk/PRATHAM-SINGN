import React from 'react';
import { useApp } from '../context/AppContext';
import {
  CalendarDays,
  CheckCheck,
  Clock,
  MapPin,
  User,
  ArrowRight,
  BookOpen,
  Calendar,
  AlertTriangle,
  Sparkles,
  ChevronRight,
  FileText,
  Building,
  Bell,
} from 'lucide-react';

export const StudentDashboard: React.FC = () => {
  const {
    currentUser,
    todaySchedule,
    overallAttendance,
    assignments,
    events,
    notifications,
    setActiveTab,
    triggerSosBroadcast,
  } = useApp();

  // Find next upcoming class or currently ongoing class
  const nextClass =
    todaySchedule.classes.find(c => c.status === 'Ongoing') ||
    todaySchedule.classes.find(c => c.status === 'Upcoming') ||
    todaySchedule.classes[0];

  // Nearest pending assignment
  const pendingAssignments = assignments
    .filter(a => a.status === 'Pending')
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  const nextAssignment = pendingAssignments[0] || assignments[0];

  // Next campus event
  const nextEvent = events[0];

  const unreadNotifs = notifications.filter(n => !n.read).slice(0, 3);

  const studentName = currentUser?.name || 'Aarav Sharma';

  // Greeting time
  const getGreeting = () => {
    const hours = new Date().getHours();
    if (hours < 12) return 'Good morning';
    if (hours < 17) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Welcome Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 text-white relative overflow-hidden border border-blue-500/20 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-[11px] font-semibold text-cyan-300">
              <Building className="w-3.5 h-3.5" />
              <span>KCC ITM Greater Noida · Knowledge Park III</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {getGreeting()}, {studentName} 👋
            </h1>

            <p className="text-sm text-slate-300 font-medium">
              Welcome to KCC ITM Smart Campus
            </p>
            <p className="text-xs text-slate-400">
              {currentUser?.course || 'B.Tech Computer Science & Engineering'} · {currentUser?.year || '3rd Year'} (Roll: {currentUser?.studentId || 'KCC2024CS089'})
            </p>
          </div>

          {/* Quick Shortcuts */}
          <div className="flex flex-wrap gap-2.5">
            <button
              onClick={() => setActiveTab('timetable')}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold backdrop-blur-md border border-white/20 transition-colors flex items-center gap-2"
            >
              <CalendarDays className="w-4 h-4 text-cyan-400" />
              <span>Today's Schedule</span>
            </button>
            <button
              onClick={() => setActiveTab('attendance')}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold backdrop-blur-md border border-white/20 transition-colors flex items-center gap-2"
            >
              <CheckCheck className="w-4 h-4 text-emerald-400" />
              <span>Attendance Calculator</span>
            </button>
          </div>
        </div>
      </div>

      {/* TODAY'S CORE METRICS ROW */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* 1. Today's Classes Card (Automatically Calculated) */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Today · Schedule
              </span>
              <span className="text-xs font-semibold text-blue-600 dark:text-cyan-400">
                {todaySchedule.dayName}
              </span>
            </div>

            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums">
                {todaySchedule.totalClasses}
              </span>
              <span className="text-sm font-bold text-slate-600 dark:text-slate-300">
                Classes Scheduled
              </span>
            </div>

            {todaySchedule.isHoliday ? (
              <p className="mt-2 text-xs text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 p-2.5 rounded-xl border border-amber-200 dark:border-amber-900/60 font-medium">
                {todaySchedule.holidayInfo?.name || 'Holiday / No classes today.'}
              </p>
            ) : (
              <div className="grid grid-cols-2 gap-3 mt-4">
                <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/50">
                  <span className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 block">
                    Completed
                  </span>
                  <span className="text-xl font-bold font-mono text-emerald-800 dark:text-emerald-200 tabular-nums">
                    {todaySchedule.completedClasses}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/50">
                  <span className="text-[11px] font-semibold text-blue-700 dark:text-blue-400 block">
                    Remaining
                  </span>
                  <span className="text-xl font-bold font-mono text-blue-800 dark:text-blue-200 tabular-nums">
                    {todaySchedule.remainingClasses}
                  </span>
                </div>
              </div>
            )}
          </div>

          <button
            onClick={() => setActiveTab('timetable')}
            className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-blue-600 dark:text-cyan-400 hover:underline"
          >
            <span>View full daily timetable</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* 2. Overall Attendance Card */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Attendance Standing
              </span>
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${
                  overallAttendance.isSafe
                    ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                    : 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                }`}
              >
                {overallAttendance.isSafe ? '🟢 Safe (≥75%)' : '🔴 Critical (<75%)'}
              </span>
            </div>

            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums">
                {overallAttendance.percentage}%
              </span>
              <span className="text-xs text-slate-500">Overall Campus Attendance</span>
            </div>

            {/* Progress bar */}
            <div className="mt-3 w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-500 ${
                  overallAttendance.isSafe ? 'bg-emerald-500' : 'bg-rose-500'
                }`}
                style={{ width: `${Math.min(overallAttendance.percentage, 100)}%` }}
              />
            </div>

            <div className="grid grid-cols-3 gap-2 mt-4 text-center">
              <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60">
                <span className="text-[10px] text-slate-400 block">Present</span>
                <span className="text-sm font-bold font-mono text-slate-800 dark:text-slate-100 tabular-nums">
                  {overallAttendance.presentCount}
                </span>
              </div>
              <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60">
                <span className="text-[10px] text-slate-400 block">Absent</span>
                <span className="text-sm font-bold font-mono text-slate-800 dark:text-slate-100 tabular-nums">
                  {overallAttendance.absentCount}
                </span>
              </div>
              <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60">
                <span className="text-[10px] text-slate-400 block">Required</span>
                <span className="text-sm font-bold font-mono text-slate-800 dark:text-slate-100 tabular-nums">
                  75.0%
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={() => setActiveTab('attendance')}
            className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-blue-600 dark:text-cyan-400 hover:underline"
          >
            <span>Open Attendance Calculator</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* 3. Next Class Spotlight Card */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Up Next on Campus
              </span>
              {nextClass && (
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    nextClass.status === 'Ongoing'
                      ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 animate-pulse'
                      : 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                  }`}
                >
                  {nextClass.status}
                </span>
              )}
            </div>

            {nextClass ? (
              <div className="space-y-2">
                <h3 className="text-base font-bold text-slate-900 dark:text-white leading-tight">
                  {nextClass.subjectName}
                </h3>
                <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="font-mono font-medium">
                      {nextClass.startTime} – {nextClass.endTime}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>
                      {nextClass.room} · {nextClass.building}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{nextClass.facultyName}</span>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-500 py-4">
                No further classes scheduled for today. Have a productive study session!
              </p>
            )}
          </div>

          <button
            onClick={() => setActiveTab('map')}
            className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-blue-600 dark:text-cyan-400 hover:underline"
          >
            <span>Navigate to Lecture Hall</span>
            <MapPin className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* SECOND ROW: ACADEMICS & EVENTS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Nearest Assignment Card */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-blue-500" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Upcoming Assignment
                </span>
              </div>
              <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                Due {nextAssignment?.dueDate}
              </span>
            </div>

            {nextAssignment ? (
              <div>
                <span className="text-[11px] font-semibold text-blue-600 dark:text-cyan-400">
                  {nextAssignment.subjectCode} · {nextAssignment.subjectName}
                </span>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-1">
                  {nextAssignment.title}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                  {nextAssignment.description}
                </p>
                <div className="mt-3 text-[11px] text-slate-400">
                  Faculty: <strong>{nextAssignment.facultyName}</strong> · Total marks: {nextAssignment.totalMarks}
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-500">All course submissions are up to date.</p>
            )}
          </div>

          <button
            onClick={() => setActiveTab('assignments')}
            className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-blue-600 dark:text-cyan-400 hover:underline"
          >
            <span>Open Assignment Center</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Nearest Campus Event Card */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-purple-500" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Upcoming Campus Event
                </span>
              </div>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-purple-50 dark:bg-purple-950 text-purple-700 dark:text-purple-300">
                {nextEvent?.category}
              </span>
            </div>

            {nextEvent ? (
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  {nextEvent.title}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                  {nextEvent.description}
                </p>
                <div className="mt-3 space-y-1 text-xs text-slate-600 dark:text-slate-300 font-medium">
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{nextEvent.date} · {nextEvent.time}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>{nextEvent.venue}</span>
                  </div>
                </div>
              </div>
            ) : null}
          </div>

          <button
            onClick={() => setActiveTab('events')}
            className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-blue-600 dark:text-cyan-400 hover:underline"
          >
            <span>Explore Events & Passes</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Unread Notifications / Alerts Feed */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-amber-500" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Campus Alerts & Notices
                </span>
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                {unreadNotifs.length} active
              </span>
            </div>

            <div className="space-y-2.5">
              {unreadNotifs.length === 0 ? (
                <p className="text-xs text-slate-400 py-4 text-center">
                  No pending critical alerts.
                </p>
              ) : (
                unreadNotifs.map(notif => (
                  <div
                    key={notif.id}
                    onClick={() => {
                      if (notif.linkTab) setActiveTab(notif.linkTab);
                    }}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition-colors text-xs space-y-0.5"
                  >
                    <p className="font-semibold text-slate-900 dark:text-white">
                      {notif.title}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                      {notif.message}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>

          <button
            onClick={triggerSosBroadcast}
            className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-rose-600 dark:text-rose-400 hover:underline"
          >
            <span>Campus Security Hotlines</span>
            <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
          </button>
        </div>
      </div>
    </div>
  );
};
