import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CAMPUS_INTELLIGENCE_DATA } from '../data/mockData';
import {
  Zap,
  Sun,
  Droplet,
  Cpu,
  TrendingUp,
  Sparkles,
  BarChart3,
  Layers,
  Activity,
  ArrowUpRight,
  ShieldCheck,
} from 'lucide-react';

export const CampusIntelligenceView: React.FC = () => {
  const [activeMetric, setActiveMetric] = useState<'power' | 'water' | 'labs'>('power');

  const { powerStats, waterStats, labUtilization, aiInsights } = CAMPUS_INTELLIGENCE_DATA;

  const maxWeeklyUsage = Math.max(...powerStats.weeklyTrend.map(w => w.usage));

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
          <Zap className="w-6 h-6 text-purple-600 dark:text-cyan-400" />
          <span>KCC Campus Intelligence & IoT Telemetry</span>
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Real-time resource analytics, classroom capacity heatmaps, and AI sustainability telemetry
        </p>
      </div>

      {/* Top 4 Real-time Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Power Demand</span>
            <div className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950 text-purple-600 dark:text-purple-400">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono text-slate-900 dark:text-white tabular-nums">
              {powerStats.todayKwh.toLocaleString()}
            </span>
            <span className="text-xs text-slate-500">kWh Today</span>
          </div>
          <p className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold mt-1">
            +6.1% vs Yesterday (3,620 kWh)
          </p>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Solar Generation</span>
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-400">
              <Sun className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono text-emerald-600 dark:text-emerald-400 tabular-nums">
              {powerStats.solarGenerationKwh.toLocaleString()}
            </span>
            <span className="text-xs text-slate-500">kWh Clean Energy</span>
          </div>
          <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold mt-1">
            Offsetting 33.3% of daytime load
          </p>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Water Recycled (STP)</span>
            <div className="p-2 rounded-xl bg-cyan-50 dark:bg-cyan-950 text-cyan-600 dark:text-cyan-400">
              <Droplet className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono text-slate-900 dark:text-white tabular-nums">
              {waterStats.recycledStpLiters.toLocaleString()}
            </span>
            <span className="text-xs text-slate-500">Liters / Day</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            STP Plant Efficiency: {waterStats.efficiencyRate}%
          </p>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Computing Labs</span>
            <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400">
              <Cpu className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold font-mono text-blue-600 dark:text-cyan-400 tabular-nums">
              88.4%
            </span>
            <span className="text-xs text-slate-500">Active Workstations</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Peak concurrency in Turing Lab
          </p>
        </div>
      </div>

      {/* 🧠 AI-Generated Institutional Insights */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-purple-900 via-indigo-950 to-slate-900 text-white border border-purple-400/30 shadow-xl space-y-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-cyan-400 animate-pulse" />
          <h3 className="text-sm font-bold uppercase tracking-wider text-cyan-300 font-mono">
            CampusAI Operational Insights
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          {aiInsights.map((insight, idx) => (
            <div
              key={idx}
              className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10 leading-relaxed text-slate-200 flex items-start gap-2.5"
            >
              <span className="font-mono font-bold text-cyan-300">0{idx + 1}.</span>
              <p>{insight}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Telemetry Visuals */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Weekly Power & Solar Trend Chart */}
        <div className="lg:col-span-7 p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Weekly Electricity vs Solar Generation
              </h3>
              <p className="text-xs text-slate-500">
                Hourly telemetry recorded at Academic Block Substation
              </p>
            </div>

            <div className="flex items-center gap-4 text-xs font-semibold">
              <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                Grid Load
              </span>
              <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                Solar Rooftop
              </span>
            </div>
          </div>

          {/* Bar Chart Representation */}
          <div className="pt-6 pb-2">
            <div className="flex items-end justify-between gap-3 h-48">
              {powerStats.weeklyTrend.map(item => (
                <div key={item.day} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                  <div className="w-full flex items-end justify-center gap-1 h-full">
                    {/* Grid load bar */}
                    <div
                      className="w-1/2 bg-blue-600 hover:bg-blue-700 rounded-t-lg transition-all"
                      style={{ height: `${(item.usage / maxWeeklyUsage) * 100}%` }}
                      title={`${item.usage} kWh Grid Load`}
                    />
                    {/* Solar bar */}
                    <div
                      className="w-1/2 bg-amber-400 hover:bg-amber-500 rounded-t-lg transition-all"
                      style={{ height: `${(item.solar / maxWeeklyUsage) * 100}%` }}
                      title={`${item.solar} kWh Solar`}
                    />
                  </div>
                  <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400">
                    {item.day}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Real-time Computing Lab Workstation Utilization */}
        <div className="lg:col-span-5 p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Computing Laboratories Workstation Loads
            </h3>
            <p className="text-xs text-slate-500">
              Monitored via campus LAN active IP allocations
            </p>
          </div>

          <div className="space-y-3 pt-1">
            {labUtilization.map((lab, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {lab.name}
                  </span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">
                    {lab.activeWorkstations} ({lab.rate}%)
                  </span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      lab.rate >= 90
                        ? 'bg-rose-500'
                        : lab.rate >= 80
                        ? 'bg-blue-600'
                        : 'bg-emerald-500'
                    }`}
                    style={{ width: `${lab.rate}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
