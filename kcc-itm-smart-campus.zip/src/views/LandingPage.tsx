import React from 'react';
import { useApp } from '../context/AppContext';
import { KccLogo } from '../components/KccLogo';
import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  GraduationCap,
  Users,
  Calendar,
  CheckCheck,
  MapPin,
  Bot,
  Wrench,
  Search,
  AlertTriangle,
  Zap,
  Building,
  Award,
  Layers,
  Clock,
  Compass,
} from 'lucide-react';
import { UserRole } from '../types';

export const LandingPage: React.FC = () => {
  const { setActiveTab, switchRole, notices } = useApp();

  const handleLaunchDemo = (role: UserRole) => {
    switchRole(role);
    if (role === 'admin') setActiveTab('admin');
    else setActiveTab('dashboard');
  };

  const featureCards = [
    {
      icon: <Bot className="w-5 h-5 text-cyan-500" />,
      title: 'CampusAI',
      badge: 'Gemini 3.8 Powered',
      description: 'Intelligent real-time assistant for schedules, attendance forecasts, and campus directions.',
      tab: 'dashboard',
    },
    {
      icon: <CheckCheck className="w-5 h-5 text-emerald-500" />,
      title: 'Smart Attendance',
      badge: 'Auto Calculations',
      description: 'Connected directly to timetable with real-time target calculations and safe threshold warnings.',
      tab: 'attendance',
    },
    {
      icon: <Calendar className="w-5 h-5 text-blue-500" />,
      title: 'Smart Timetable',
      badge: 'Single Source of Truth',
      description: 'Automatic daily and weekly class counters, time-based class status, and holiday awareness.',
      tab: 'timetable',
    },
    {
      icon: <MapPin className="w-5 h-5 text-indigo-500" />,
      title: 'Digital Campus',
      badge: 'Interactive Map',
      description: 'Interactive navigation across Academic Blocks, Computing Labs, Library, and Amenities.',
      tab: 'map',
    },
    {
      icon: <Award className="w-5 h-5 text-amber-500" />,
      title: 'Events Hub',
      badge: 'Passes & Fests',
      description: 'Discover national hackathons, technical workshops, and cultural fests with 1-click registration.',
      tab: 'events',
    },
    {
      icon: <Wrench className="w-5 h-5 text-orange-500" />,
      title: 'Campus Services',
      badge: 'AI Grievance Router',
      description: 'Automated problem classification, real-time ticket progression, and hostel maintenance.',
      tab: 'complaints',
    },
    {
      icon: <Search className="w-5 h-5 text-teal-500" />,
      title: 'Lost & Found',
      badge: 'Smart Matching',
      description: 'Intelligent campus matching between reported missing items and secure collection points.',
      tab: 'lostfound',
    },
    {
      icon: <AlertTriangle className="w-5 h-5 text-rose-500" />,
      title: 'Emergency Center',
      badge: '24x7 Priority',
      description: 'Direct priority dialers for Security, Medical Center, Ambulance, and Instant SOS Beacon.',
      tab: 'emergency',
    },
    {
      icon: <Zap className="w-5 h-5 text-purple-500" />,
      title: 'Campus Intelligence',
      badge: 'IoT & Telemetry',
      description: 'Real-time solar generation, electricity demand, water recycling, and AI facility insights.',
      tab: 'intelligence',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 sm:pt-20 sm:pb-28 border-b border-slate-200 dark:border-slate-800">
        {/* Futuristic subtle background gradient glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-blue-600/15 via-cyan-500/10 to-indigo-600/15 blur-3xl pointer-events-none rounded-full" />

        <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10 text-center">
          {/* Institutional Trust Kicker */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 dark:bg-blue-950/70 border border-blue-200 dark:border-blue-800 text-xs font-semibold text-blue-700 dark:text-cyan-300 mb-6 shadow-sm">
            <Building className="w-3.5 h-3.5" />
            <span>KCC Institute of Technology and Management · Greater Noida</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white max-w-4xl mx-auto leading-[1.15]">
            KCC ITM SMART CAMPUS
          </h1>

          <p className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 bg-clip-text text-transparent mt-3">
            The Campus, Reimagined.
          </p>

          <p className="mt-4 text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
            One intelligent platform connecting KCC ITM students, academics, facilities and campus services.
          </p>

          {/* Primary Action Buttons */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3.5">
            <button
              onClick={() => handleLaunchDemo('student')}
              className="px-6 py-3.5 rounded-xl font-bold text-sm bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-600/25 active:scale-95 transition-all flex items-center gap-2"
            >
              <span>Enter Smart Campus</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => {
                const el = document.getElementById('features-section');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-6 py-3.5 rounded-xl font-semibold text-sm bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-300 dark:border-slate-700 shadow-sm transition-all"
            >
              Explore Features
            </button>
          </div>

          {/* 1-Click Role Demonstrator Bar */}
          <div className="mt-12 p-4 sm:p-5 rounded-2xl bg-white/80 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 shadow-xl max-w-3xl mx-auto backdrop-blur-md">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-3">
              Instant Institutional Demo Access · No Manual Credentials Required
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                onClick={() => handleLaunchDemo('student')}
                className="flex items-center gap-3 p-3 rounded-xl border border-blue-200 dark:border-blue-900/60 bg-blue-50/60 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/60 transition-colors text-left group"
              >
                <div className="w-9 h-9 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1">
                    Student Portal
                    <ArrowRight className="w-3 h-3 text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    Aarav Sharma (B.Tech CSE)
                  </div>
                </div>
              </button>

              <button
                onClick={() => handleLaunchDemo('admin')}
                className="flex items-center gap-3 p-3 rounded-xl border border-purple-200 dark:border-purple-900/60 bg-purple-50/60 dark:bg-purple-950/40 hover:bg-purple-100 dark:hover:bg-purple-900/60 transition-colors text-left group"
              >
                <div className="w-9 h-9 rounded-lg bg-purple-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1">
                    Admin Console
                    <ArrowRight className="w-3 h-3 text-purple-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    Prof. Rajiv Nandan (Dean)
                  </div>
                </div>
              </button>

              <button
                onClick={() => handleLaunchDemo('faculty')}
                className="flex items-center gap-3 p-3 rounded-xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/60 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 transition-colors text-left group"
              >
                <div className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  <Users className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1">
                    Faculty Desk
                    <ArrowRight className="w-3 h-3 text-emerald-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    Dr. Priya Verma (HOD)
                  </div>
                </div>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Digitally Connected Campus Overview Banner */}
      <section className="py-12 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 text-white relative overflow-hidden border border-blue-500/20 shadow-xl">
            {/* Visual tech grid decorative overlay */}
            <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px]" />

            <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="space-y-4">
                <span className="text-xs font-mono font-bold tracking-wider uppercase text-cyan-400">
                  Digital Operating System
                </span>
                <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
                  Seamlessly Interconnected Campus Life
                </h2>
                <p className="text-sm text-slate-300 leading-relaxed">
                  Every lecture, attendance percentage, campus facility, grievance ticket, and emergency dispatch operates on a unified institutional backbone.
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-2">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                    <p className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">2,480+</p>
                    <p className="text-[11px] text-slate-400">Enrolled Students</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                    <p className="text-2xl font-bold font-mono text-blue-400 tabular-nums">100%</p>
                    <p className="text-[11px] text-slate-400">Timetable Automated</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 col-span-2 sm:col-span-1">
                    <p className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">&lt; 2 Hrs</p>
                    <p className="text-[11px] text-slate-400">Service Response</p>
                  </div>
                </div>
              </div>

              {/* Graphic Vector Representation of KCC Smart Campus */}
              <div className="relative flex items-center justify-center p-6 bg-slate-900/60 rounded-2xl border border-white/10">
                <div className="w-full max-w-sm space-y-3">
                  <div className="p-3 rounded-xl bg-blue-900/40 border border-blue-400/30 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <Calendar className="w-4 h-4 text-cyan-400" />
                      <span className="text-xs font-semibold">Today's Class Counter</span>
                    </div>
                    <span className="text-xs font-mono font-bold text-cyan-300">5 Scheduled</span>
                  </div>

                  <div className="p-3 rounded-xl bg-indigo-900/40 border border-indigo-400/30 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <CheckCheck className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-semibold">Attendance Engine</span>
                    </div>
                    <span className="text-xs font-mono font-bold text-emerald-300">82.4% Safe</span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-800/80 border border-white/10 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <Bot className="w-4 h-4 text-purple-400" />
                      <span className="text-xs font-semibold">CampusAI Assistant</span>
                    </div>
                    <span className="text-xs font-mono text-purple-300">Online & Ready</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Sections Grid */}
      <section id="features-section" className="py-16 sm:py-24 max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Built for Academic Excellence & Operational Precision
          </h2>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            A comprehensive institutional ecosystem designed specifically for KCC Institute of Technology and Management.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {featureCards.map((feat, idx) => (
            <div
              key={idx}
              onClick={() => {
                handleLaunchDemo('student');
                setActiveTab(feat.tab);
              }}
              className="group p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-700 shadow-sm hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 group-hover:scale-105 transition-transform">
                    {feat.icon}
                  </div>
                  <span className="text-[11px] font-semibold text-blue-600 dark:text-cyan-400">
                    {feat.badge}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-cyan-400 transition-colors">
                  {feat.title}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 leading-relaxed">
                  {feat.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs font-semibold text-blue-600 dark:text-cyan-400">
                <span>Open module</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Institutional Notices Feed */}
      <section className="py-12 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Official Campus Notices & Bulletins
              </h2>
              <p className="text-xs text-slate-500">
                Directives from the Dean of Academic Affairs & Controller of Examinations
              </p>
            </div>
            <button
              onClick={() => handleLaunchDemo('student')}
              className="text-xs font-semibold text-blue-600 dark:text-cyan-400 hover:underline flex items-center gap-1"
            >
              View noticeboard <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {notices.slice(0, 4).map(notice => (
              <div
                key={notice.id}
                className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-850"
              >
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    {notice.category} · {notice.publishedBy}
                  </span>
                  <span>{notice.publishedDate}</span>
                </div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white mb-1">
                  {notice.title}
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                  {notice.content}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Institutional Footer */}
      <footer className="py-12 bg-slate-900 text-slate-400 text-xs border-t border-slate-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex flex-col items-center md:items-start gap-2">
            <KccLogo size="md" showSubtitle={true} className="text-white" />
            <p className="text-[11px] text-slate-400 mt-1 max-w-sm text-center md:text-left">
              2B-2C, Knowledge Park III, Greater Noida, Uttar Pradesh 201306. Approved by AICTE, Affiliated to Dr. A.P.J. Abdul Kalam Technical University (AKTU).
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 text-xs text-slate-300 font-medium">
            <button onClick={() => handleLaunchDemo('student')} className="hover:text-white">
              Student Dashboard
            </button>
            <button onClick={() => handleLaunchDemo('admin')} className="hover:text-white">
              Admin Portal
            </button>
            <button onClick={() => handleLaunchDemo('faculty')} className="hover:text-white">
              Faculty Desk
            </button>
            <button onClick={() => setActiveTab('emergency')} className="hover:text-rose-400">
              Campus Hotlines
            </button>
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-4 sm:px-6 mt-8 pt-6 border-t border-slate-800 text-center text-[11px] text-slate-500">
          © 2026 KCC Institute of Technology and Management. All rights reserved. KCC ITM Smart Campus Platform v2026.1.
        </div>
      </footer>
    </div>
  );
};
