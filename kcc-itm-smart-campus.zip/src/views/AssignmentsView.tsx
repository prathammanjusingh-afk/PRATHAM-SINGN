import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  FileText,
  UploadCloud,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileCheck,
  Search,
  Filter,
  X,
} from 'lucide-react';
import { Assignment } from '../types';

export const AssignmentsView: React.FC = () => {
  const { assignments, submitAssignment } = useApp();
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);
  const [uploadFileName, setUploadFileName] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'Submitted' | 'Overdue'>('All');

  const filteredAssignments = assignments.filter(a => {
    if (statusFilter === 'All') return true;
    return a.status === statusFilter;
  });

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAssignment || !uploadFileName.trim()) return;

    submitAssignment(selectedAssignment.id, uploadFileName.trim());
    setSelectedAssignment(null);
    setUploadFileName('');
  };

  const statusBadges = {
    Submitted: {
      label: 'Submitted',
      class: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800',
    },
    Pending: {
      label: 'Pending',
      class: 'bg-amber-50 text-amber-700 dark:bg-amber-950/70 dark:text-amber-300 border border-amber-200 dark:border-amber-800',
    },
    Overdue: {
      label: 'Overdue',
      class: 'bg-rose-50 text-rose-700 dark:bg-rose-950/70 dark:text-rose-300 border border-rose-200 dark:border-rose-800',
    },
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <FileText className="w-6 h-6 text-blue-600 dark:text-cyan-400" />
            <span>Academic Assignment Center</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Course deliverables, laboratory records, and continuous internal assessment submissions
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
          {(['All', 'Pending', 'Submitted', 'Overdue'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setStatusFilter(tab)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                statusFilter === tab
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Assignments List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredAssignments.map(asg => (
          <div
            key={asg.id}
            className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-blue-600 dark:text-cyan-400 px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800">
                  {asg.subjectCode} · {asg.subjectName}
                </span>

                <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${statusBadges[asg.status].class}`}>
                  {statusBadges[asg.status].label}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-2">
                {asg.title}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed">
                {asg.description}
              </p>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs space-y-1 text-slate-500">
                <div className="flex justify-between">
                  <span>Faculty Mentor:</span>
                  <span className="font-semibold text-slate-700 dark:text-slate-200">{asg.facultyName}</span>
                </div>
                <div className="flex justify-between">
                  <span>Submission Deadline:</span>
                  <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">{asg.dueDate}</span>
                </div>
                <div className="flex justify-between">
                  <span>Evaluation Weightage:</span>
                  <span className="font-mono text-slate-800 dark:text-slate-200">{asg.totalMarks} Marks</span>
                </div>

                {asg.status === 'Submitted' && asg.grade && (
                  <div className="mt-2 p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-semibold flex justify-between">
                    <span>Evaluated Grade:</span>
                    <span>{asg.grade}</span>
                  </div>
                )}

                {asg.fileName && (
                  <div className="text-[11px] text-slate-400 font-mono truncate pt-1">
                    Attached: {asg.fileName} ({asg.submittedAt})
                  </div>
                )}
              </div>
            </div>

            {/* Action Bar */}
            <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800">
              {asg.status === 'Submitted' ? (
                <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Submission Received and Recorded</span>
                </div>
              ) : (
                <button
                  onClick={() => {
                    setSelectedAssignment(asg);
                    setUploadFileName(`KCC2024CS089_${asg.subjectCode}_Report.zip`);
                  }}
                  className="w-full py-2.5 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-600/20 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <UploadCloud className="w-4 h-4" />
                  <span>Upload & Submit Assignment</span>
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Submission Modal */}
      {selectedAssignment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-mono font-bold text-blue-600 dark:text-cyan-400 uppercase">
                  {selectedAssignment.subjectCode} Submission
                </span>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white mt-1">
                  {selectedAssignment.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedAssignment(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleUpload} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  File Attachment (Zip / PDF / Code repo)
                </label>
                <div className="p-4 rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 text-center space-y-2 cursor-pointer bg-slate-50 dark:bg-slate-800/50">
                  <UploadCloud className="w-8 h-8 text-blue-500 mx-auto" />
                  <div className="text-xs text-slate-600 dark:text-slate-300">
                    <span className="font-semibold text-blue-600 dark:text-cyan-400">Click to choose file</span> or drag & drop
                  </div>
                  <input
                    type="text"
                    value={uploadFileName}
                    onChange={e => setUploadFileName(e.target.value)}
                    placeholder="e.g. KCC2024CS089_Assignment.pdf"
                    className="w-full text-center px-3 py-1.5 rounded-lg text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="text-[11px] text-slate-400">
                Institutional Academic Integrity Notice: All code is processed through anti-plagiarism filters.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedAssignment(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!uploadFileName.trim()}
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-600/20 disabled:opacity-50"
                >
                  Confirm & Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
