import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Wrench,
  Sparkles,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Send,
  Plus,
  Filter,
  Search,
  User,
  MapPin,
  HelpCircle,
  Building,
} from 'lucide-react';
import { Complaint } from '../types';

export const ComplaintsView: React.FC = () => {
  const { complaints, submitComplaint, currentUser } = useApp();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState<'All' | 'Open' | 'Resolved'>('All');

  // New complaint form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [category, setCategory] = useState<Complaint['category']>('Maintenance');
  const [priority, setPriority] = useState<Complaint['priority']>('Medium');
  const [department, setDepartment] = useState('Campus Facilities Directorate');

  // AI Classification Preview State
  const [isClassifying, setIsClassifying] = useState(false);
  const [aiClassificationResult, setAiClassificationResult] = useState<{
    category: Complaint['category'];
    priority: Complaint['priority'];
    department: string;
    reasoning?: string;
  } | null>(null);

  // Debounced auto-classification as student types description
  useEffect(() => {
    if (description.trim().length < 8) {
      setAiClassificationResult(null);
      return;
    }

    const timer = setTimeout(async () => {
      setIsClassifying(true);
      try {
        const res = await fetch('/api/ai/classify-complaint', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title, description }),
        });

        if (res.ok) {
          const data = await res.json();
          setAiClassificationResult(data);
          setCategory(data.category);
          setPriority(data.priority);
          setDepartment(data.department);
        }
      } catch (e) {
        // Fallback rule matching
        const text = `${title} ${description}`.toLowerCase();
        let cat: Complaint['category'] = 'Maintenance';
        let prio: Complaint['priority'] = 'Medium';
        let dep = 'Campus Facilities Directorate';

        if (text.includes('electricity') || text.includes('light') || text.includes('fan') || text.includes('power')) {
          cat = 'Electricity';
          prio = 'High';
          dep = 'Electrical Maintenance Division';
        } else if (text.includes('water') || text.includes('tap') || text.includes('leak')) {
          cat = 'Water';
          prio = 'Medium';
          dep = 'Civil & Plumbing Services';
        } else if (text.includes('wifi') || text.includes('internet') || text.includes('net')) {
          cat = 'Internet';
          prio = 'High';
          dep = 'Campus IT & Networks Cell';
        } else if (text.includes('hostel') || text.includes('bed')) {
          cat = 'Hostel';
          prio = 'Medium';
          dep = 'Hostel Administration Office';
        }

        setAiClassificationResult({
          category: cat,
          priority: prio,
          department: dep,
          reasoning: 'Auto-detected through institutional service heuristics.',
        });
        setCategory(cat);
        setPriority(prio);
        setDepartment(dep);
      } finally {
        setIsClassifying(false);
      }
    }, 600);

    return () => clearTimeout(timer);
  }, [description, title]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim() || !location.trim()) return;

    await submitComplaint({
      category,
      title,
      description,
      location,
      priority,
      department,
    });

    setIsFormOpen(false);
    setTitle('');
    setDescription('');
    setLocation('');
    setAiClassificationResult(null);
  };

  const filteredComplaints = complaints.filter(c => {
    if (activeFilter === 'Open') return c.status !== 'Resolved';
    if (activeFilter === 'Resolved') return c.status === 'Resolved';
    return true;
  });

  const priorityColors = {
    Low: 'text-slate-600 bg-slate-100 dark:bg-slate-800 dark:text-slate-300',
    Medium: 'text-blue-700 bg-blue-50 dark:bg-blue-950/60 dark:text-blue-300',
    High: 'text-amber-700 bg-amber-50 dark:bg-amber-950/60 dark:text-amber-300',
    Urgent: 'text-rose-700 bg-rose-50 dark:bg-rose-950/60 dark:text-rose-300 animate-pulse',
  };

  const statusColors = {
    Submitted: 'bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-300',
    Assigned: 'bg-purple-100 text-purple-800 dark:bg-purple-900/60 dark:text-purple-300',
    'In Progress': 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300',
    Resolved: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300',
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <Wrench className="w-6 h-6 text-orange-600 dark:text-orange-400" />
            <span>Campus Services & Grievance Redressal</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Automated ticket routing, AI problem categorization, and transparent service lifecycle
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsFormOpen(true)}
            className="px-4 py-2.5 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-600/20 active:scale-95 transition-all flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>Submit New Grievance</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl max-w-xs">
        {(['All', 'Open', 'Resolved'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveFilter(tab)}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-colors ${
              activeFilter === tab
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {tab} ({tab === 'All' ? complaints.length : complaints.filter(c => tab === 'Open' ? c.status !== 'Resolved' : c.status === 'Resolved').length})
          </button>
        ))}
      </div>

      {/* Grievance Ticket Cards */}
      <div className="space-y-4">
        {filteredComplaints.length === 0 ? (
          <div className="p-12 text-center rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <p className="text-xs text-slate-500">No grievance tickets found under this view.</p>
          </div>
        ) : (
          filteredComplaints.map(ticket => (
            <div
              key={ticket.id}
              className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <span className="font-mono font-bold text-xs px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-cyan-400 border border-blue-200 dark:border-blue-900">
                    {ticket.ticketId}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${priorityColors[ticket.priority]}`}>
                    {ticket.priority} Priority
                  </span>
                  <span className="text-xs font-semibold text-slate-500">
                    Category: <strong>{ticket.category}</strong>
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${statusColors[ticket.status]}`}>
                    {ticket.status}
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {ticket.submittedAt}
                  </span>
                </div>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {ticket.title}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  {ticket.description}
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-4 text-xs text-slate-500">
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>Location: {ticket.location}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Building className="w-3.5 h-3.5 text-slate-400" />
                    <span>Department: {ticket.department}</span>
                  </div>
                  {ticket.assignedTo && (
                    <div className="flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      <span>Assigned: <strong>{ticket.assignedTo}</strong></span>
                    </div>
                  )}
                </div>
              </div>

              {/* Status Stepper Progression */}
              <div className="pt-2">
                <div className="grid grid-cols-4 gap-2 text-center text-[10px] font-bold uppercase tracking-wider">
                  {(['Submitted', 'Assigned', 'In Progress', 'Resolved'] as const).map((step, idx) => {
                    const stepOrder = ['Submitted', 'Assigned', 'In Progress', 'Resolved'];
                    const currentIdx = stepOrder.indexOf(ticket.status);
                    const isDone = idx <= currentIdx;

                    return (
                      <div key={step} className="space-y-1">
                        <div
                          className={`h-1.5 rounded-full transition-colors ${
                            isDone ? 'bg-blue-600 dark:bg-cyan-400' : 'bg-slate-200 dark:bg-slate-800'
                          }`}
                        />
                        <span className={isDone ? 'text-slate-900 dark:text-white' : 'text-slate-400'}>
                          {step}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Resolution Notes or Timeline */}
              {ticket.updates && ticket.updates.length > 0 && (
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 space-y-2 text-xs">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                    Maintenance Timeline & Actions:
                  </span>
                  {ticket.updates.map((u, uIdx) => (
                    <div key={uIdx} className="flex items-start gap-2 text-slate-600 dark:text-slate-300">
                      <Clock className="w-3.5 h-3.5 text-slate-400 mt-0.5 shrink-0" />
                      <div>
                        <span className="font-semibold text-slate-900 dark:text-white">{u.author}:</span>{' '}
                        <span>{u.note}</span>{' '}
                        <span className="text-[10px] text-slate-400 font-mono">({u.timestamp})</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* New Grievance Modal with AI Classification */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 sm:p-8 space-y-4 max-h-[90vh] overflow-y-auto">
            <div>
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-blue-600 dark:text-cyan-400">
                Institutional Service Portal
              </span>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                Report Campus Grievance or Maintenance Request
              </h2>
              <p className="text-xs text-slate-500">
                Our CampusAI auto-categorizes your issue and routes it directly to the designated department.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Issue Title *
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Fluorescent Light Flickering or No Wi-Fi"
                  className="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Location on Campus *
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                  placeholder="e.g. Academic Block A, 2nd Floor, LH-201 or Boys Hostel Wing B"
                  className="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Detailed Description *
                </label>
                <textarea
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  rows={3}
                  placeholder="Describe what is wrong. Example: 'The front row ceiling fixture in LH-201 has been rapidly flickering during morning lectures...'"
                  className="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              {/* 🧠 AI Complaint Classification Box */}
              {isClassifying && (
                <div className="p-3.5 rounded-2xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 flex items-center gap-2.5 text-xs text-blue-700 dark:text-blue-300">
                  <Sparkles className="w-4 h-4 animate-spin text-cyan-500" />
                  <span>KCC CampusAI is analyzing your report & determining department routing...</span>
                </div>
              )}

              {aiClassificationResult && (
                <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-50 via-indigo-50 to-cyan-50 dark:from-slate-800/90 dark:via-blue-950/40 dark:to-slate-800/90 border border-blue-200 dark:border-blue-800/60 space-y-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-blue-600 dark:text-cyan-400" />
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      AI Automatic Classification Preview:
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className="p-2 rounded-xl bg-white/80 dark:bg-slate-900/80">
                      <span className="text-[10px] text-slate-400 block">Category</span>
                      <strong className="text-slate-900 dark:text-white">{aiClassificationResult.category}</strong>
                    </div>
                    <div className="p-2 rounded-xl bg-white/80 dark:bg-slate-900/80">
                      <span className="text-[10px] text-slate-400 block">Priority</span>
                      <strong className="text-amber-600 dark:text-amber-400">{aiClassificationResult.priority}</strong>
                    </div>
                    <div className="p-2 rounded-xl bg-white/80 dark:bg-slate-900/80">
                      <span className="text-[10px] text-slate-400 block">Assigned Dept</span>
                      <strong className="text-slate-900 dark:text-white truncate block">{aiClassificationResult.department}</strong>
                    </div>
                  </div>

                  {aiClassificationResult.reasoning && (
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 italic">
                      "{aiClassificationResult.reasoning}"
                    </p>
                  )}
                </div>
              )}

              {/* Form Controls to override if desired */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Category (Manual Override)
                  </label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  >
                    <option value="Hostel">Hostel</option>
                    <option value="Mess">Mess</option>
                    <option value="Electricity">Electricity</option>
                    <option value="Water">Water</option>
                    <option value="Internet">Internet</option>
                    <option value="Classroom">Classroom</option>
                    <option value="Laboratory">Laboratory</option>
                    <option value="Cleaning">Cleaning</option>
                    <option value="Security">Security</option>
                    <option value="Maintenance">Maintenance</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                    Priority
                  </label>
                  <select
                    value={priority}
                    onChange={e => setPriority(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Urgent">Urgent</option>
                  </select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl font-bold text-xs bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-600/20 active:scale-95 transition-all flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit & Generate KCC Ticket ID</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
