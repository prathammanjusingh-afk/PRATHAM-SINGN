import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Calendar,
  Clock,
  MapPin,
  Users,
  Award,
  CheckCircle2,
  Ticket,
  Search,
  Filter,
  ArrowRight,
  Share2,
} from 'lucide-react';
import { CampusEvent } from '../types';

export const EventsHubView: React.FC = () => {
  const { events, registerForEvent, unregisterFromEvent, currentUser, addToast } = useApp();
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTicketEvent, setSelectedTicketEvent] = useState<CampusEvent | null>(null);

  const categories = [
    'All',
    'Hackathons',
    'Workshops',
    'Cultural',
    'Sports',
    'Seminars',
  ];

  const filteredEvents = events.filter(evt => {
    const matchesCat = activeCategory === 'All' || evt.category === activeCategory;
    const matchesSearch =
      evt.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evt.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evt.venue.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <Award className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            <span>KCC Events Hub & Fests</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Discover, participate and secure institutional registration passes for campus competitions
          </p>
        </div>

        {/* Search Bar */}
        <div className="relative w-full sm:w-72">
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search fests, hackathons, sports..."
            className="w-full pl-9 pr-4 py-2 rounded-xl text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
        </div>
      </div>

      {/* Categories Bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap transition-colors ${
              activeCategory === cat
                ? 'bg-purple-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Events Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredEvents.map(evt => {
          const isRegistered = currentUser && evt.registeredUserIds.includes(currentUser.id);
          const remainingSeats = evt.maxSeats - evt.registeredUserIds.length;

          return (
            <div
              key={evt.id}
              className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div>
                {/* Styled Decorative Banner */}
                <div
                  className={`p-5 text-white bg-gradient-to-r ${
                    evt.category === 'Hackathons'
                      ? 'from-blue-700 via-indigo-700 to-slate-900'
                      : evt.category === 'Cultural'
                      ? 'from-purple-700 via-pink-700 to-rose-900'
                      : evt.category === 'Sports'
                      ? 'from-emerald-700 via-teal-700 to-slate-900'
                      : 'from-slate-800 via-blue-900 to-indigo-950'
                  } relative overflow-hidden`}
                >
                  <div className="relative z-10 flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-white/20 backdrop-blur-md">
                      {evt.category}
                    </span>
                    <span className="text-[10px] font-medium bg-black/30 px-2 py-0.5 rounded-full">
                      {evt.tag}
                    </span>
                  </div>

                  <h3 className="relative z-10 text-base font-bold tracking-tight mt-3 text-white leading-snug">
                    {evt.title}
                  </h3>
                </div>

                {/* Details Body */}
                <div className="p-5 space-y-3">
                  <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
                    {evt.description}
                  </p>

                  <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300 font-medium pt-1">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{evt.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{evt.time}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{evt.venue}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="text-slate-500">Org: {evt.organizer}</span>
                    </div>
                  </div>

                  {/* Seat count badge */}
                  <div className="pt-2 flex items-center justify-between text-[11px] text-slate-500 border-t border-slate-100 dark:border-slate-800">
                    <span>
                      Registrations: <strong>{evt.registeredUserIds.length}</strong> / {evt.maxSeats}
                    </span>
                    <span className="font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                      {remainingSeats} seats left
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Bar */}
              <div className="p-5 pt-0">
                {isRegistered ? (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setSelectedTicketEvent(evt)}
                      className="flex-1 py-2 rounded-xl text-xs font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors flex items-center justify-center gap-1.5"
                    >
                      <Ticket className="w-4 h-4" />
                      <span>View Pass</span>
                    </button>
                    <button
                      onClick={() => unregisterFromEvent(evt.id)}
                      className="px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-900/40 transition-colors"
                      title="Withdraw Registration"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => registerForEvent(evt.id)}
                    className="w-full py-2.5 rounded-xl font-bold text-xs bg-purple-600 hover:bg-purple-700 text-white shadow-md shadow-purple-600/20 active:scale-95 transition-all flex items-center justify-center gap-2"
                  >
                    <span>Register Now</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Ticket Pass Modal */}
      {selectedTicketEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden p-6 text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
              <Ticket className="w-6 h-6" />
            </div>

            <div>
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
                Official Event Pass
              </span>
              <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
                {selectedTicketEvent.title}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {selectedTicketEvent.date} · {selectedTicketEvent.venue}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2 text-left text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Participant:</span>
                <span className="font-bold text-slate-900 dark:text-white">{currentUser?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Student ID:</span>
                <span className="font-mono text-slate-700 dark:text-slate-300">{currentUser?.studentId || 'KCC2024CS089'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Department:</span>
                <span className="text-slate-700 dark:text-slate-300">{currentUser?.department}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-200 dark:border-slate-700">
                <span className="text-slate-400">Gate Pass QR / Token:</span>
                <span className="font-mono font-bold text-blue-600 dark:text-cyan-400">
                  PASS-KCC-{selectedTicketEvent.id.toUpperCase()}-7721
                </span>
              </div>
            </div>

            <button
              onClick={() => setSelectedTicketEvent(null)}
              className="w-full py-2.5 rounded-xl font-bold text-xs bg-slate-900 dark:bg-white text-white dark:text-slate-900 transition-colors"
            >
              Close Pass
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
