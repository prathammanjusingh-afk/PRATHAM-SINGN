import React from 'react';
import { useApp } from '../context/AppContext';
import {
  AlertOctagon,
  PhoneCall,
  ShieldAlert,
  HeartPulse,
  Flame,
  Radio,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  Building,
} from 'lucide-react';

export const EmergencyView: React.FC = () => {
  const { triggerSosBroadcast } = useApp();

  const emergencyContacts = [
    {
      title: 'Campus Security Main Command',
      number: '0120-2323-999',
      ext: 'Ext. 100',
      timing: '24 Hours / 365 Days',
      location: 'Main Gate Control Room',
      description: 'Proctorial guard dispatch, gate security, and instant campus emergency lockdown coordination.',
      icon: <ShieldAlert className="w-6 h-6 text-rose-600 dark:text-rose-400" />,
      actionLabel: 'Call Security',
    },
    {
      title: 'Medical Health Center & Observation',
      number: '+91 98110 11108',
      ext: 'Ext. 108',
      timing: '24 Hours Emergency Ward',
      location: 'Administrative Block (Ground Floor East)',
      description: 'On-duty Medical Officer, nursing staff, essential pharmaceuticals, oxygen, and emergency stabilization beds.',
      icon: <HeartPulse className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />,
      actionLabel: 'Call Doctor',
    },
    {
      title: '24x7 Dedicated Campus Ambulance',
      number: '102 / Ext. 102',
      ext: 'Ext. 102',
      timing: 'Immediate Dispatch',
      location: 'Ambulance Bay, Admin Ramp',
      description: 'Equipped with basic life support (BLS). Priority transfer agreement with Kailash & Sharda Hospitals.',
      icon: <AlertOctagon className="w-6 h-6 text-amber-600 dark:text-amber-400" />,
      actionLabel: 'Request Ambulance',
    },
    {
      title: 'Fire Emergency & Safety Unit',
      number: '101 / Ext. 101',
      ext: 'Ext. 101',
      timing: '24 Hours Readiness',
      location: 'Greater Noida KP-III Fire Station Unit',
      description: 'Campus fire hydrants, automated CO2 lab suppression systems, and trained safety marshals.',
      icon: <Flame className="w-6 h-6 text-red-600 dark:text-red-400" />,
      actionLabel: 'Report Fire',
    },
    {
      title: 'Women Safety & ICC Cell',
      number: '1090 / Ext. 145',
      ext: 'Ext. 145',
      timing: '24x7 Confidential Hotline',
      location: 'Girls Hostel Warden Office',
      description: 'Strict confidential assistance, female security escort after library hours, and proctorial support.',
      icon: <PhoneCall className="w-6 h-6 text-purple-600 dark:text-purple-400" />,
      actionLabel: 'Call Women Cell',
    },
    {
      title: 'National Anti-Ragging Helpline',
      number: '1800-180-5522',
      ext: 'Toll-Free',
      timing: '24x7 Zero-Tolerance',
      location: 'Dean of Student Welfare Office',
      description: 'UGC and institutional zero-tolerance policy against any form of ragging or harassment.',
      icon: <AlertTriangle className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />,
      actionLabel: 'Anti-Ragging Call',
    },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
          <AlertOctagon className="w-6 h-6 text-rose-600 dark:text-rose-400" />
          <span>KCC Emergency & Disaster Center</span>
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          High-priority emergency hotlines, medical assistance, and instant distress dispatch
        </p>
      </div>

      {/* Instant SOS Hero Action Bar */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-rose-600 via-red-600 to-slate-900 text-white relative overflow-hidden shadow-xl border border-rose-500/30">
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold uppercase tracking-wider">
              <Radio className="w-4 h-4 animate-ping" />
              <span>Campus Distress Beacon</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              In Danger or Witnessing an Emergency?
            </h2>
            <p className="text-xs sm:text-sm text-rose-100 max-w-xl">
              One click alerts the Main Gate Security Command Center and Medical Doctor with your student GPS beacon and profile immediately.
            </p>
          </div>

          <button
            onClick={triggerSosBroadcast}
            className="px-8 py-4 rounded-2xl bg-white text-rose-700 hover:bg-rose-50 active:scale-95 font-extrabold text-sm uppercase tracking-wider shadow-2xl transition-all shrink-0 flex items-center gap-2.5"
          >
            <AlertOctagon className="w-5 h-5 text-rose-600" />
            <span>Broadcast SOS Beacon</span>
          </button>
        </div>
      </div>

      {/* Directory of Emergency Lines */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {emergencyContacts.map((c, idx) => (
          <div
            key={idx}
            className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  {c.icon}
                </div>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                  {c.ext}
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {c.title}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                  {c.description}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-xs space-y-1 text-slate-500">
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{c.location}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  <span>{c.timing}</span>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800">
              <a
                href={`tel:${c.number.replace(/[^0-9+]/g, '')}`}
                className="w-full py-2.5 rounded-xl font-bold text-xs bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white transition-colors flex items-center justify-center gap-2"
              >
                <PhoneCall className="w-4 h-4 text-emerald-400" />
                <span>{c.actionLabel}: {c.number}</span>
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Evacuation and Safety Guidelines */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <h3 className="text-base font-bold text-slate-900 dark:text-white">
          KCC ITM Campus Emergency Protocols
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-600 dark:text-slate-300">
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-1">
            <span className="font-bold text-slate-900 dark:text-white block">1. Fire Evacuation</span>
            <p>Do not use elevators. Follow green directional illuminated exit signs to the primary outdoor cricket grounds muster point.</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-1">
            <span className="font-bold text-slate-900 dark:text-white block">2. Medical Emergency</span>
            <p>Notify lecture faculty or floor warden immediately. Ext 108 connects with Medical Observation Room for stretcher dispatch.</p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-1">
            <span className="font-bold text-slate-900 dark:text-white block">3. Safety Escort</span>
            <p>Students working late in Computing Labs past 08:30 PM can request security guard transit escort to Hostels via Ext 100.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
