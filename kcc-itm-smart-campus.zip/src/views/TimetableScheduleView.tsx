import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  CalendarDays,
  Clock,
  MapPin,
  User,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Layers,
  History,
  TrendingUp,
} from 'lucide-react';
import { ClassStatus } from '../types';

export const TimetableScheduleView: React.FC = () => {
  const {
    selectedDate,
    setSelectedDate,
    getDateSchedule,
    weeklySummary,
    subjectFrequency,
    markClassAttendance,
    pastAttendance,
    todaySchedule,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'daily' | 'weekly' | 'history' | 'subjects'>('daily');

  // Computed schedule for the currently selected calendar date
  const schedule = getDateSchedule(selectedDate);

  // Fast navigation helper for date selector (e.g. Previous day, Next day, Today)
  const shiftDate = (days: number) => {
    const [y, m, d] = selectedDate.split('-').map(Number);
    const curr = new Date(y, m - 1, d);
    curr.setDate(curr.getDate() + days);
    const nextY = curr.getFullYear();
    const nextM = String(curr.getMonth() + 1).padStart(2, '0');
    const nextD = String(curr.getDate()).padStart(2, '0');
    setSelectedDate(`${nextY}-${nextM}-${nextD}`);
  };

  const setDateToday = () => {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    setSelectedDate(`${y}-${m}-${d}`);
  };

  // Status badge styling
  const statusBadges: Record<ClassStatus, { label: string; class: string }> = {
    Completed: {
      label: 'Completed',
      class: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800',
    },
    Ongoing: {
      label: 'Ongoing',
      class: 'bg-amber-50 text-amber-700 dark:bg-amber-950/70 dark:text-amber-300 border border-amber-200 dark:border-amber-800 animate-pulse',
    },
    Upcoming: {
      label: 'Upcoming',
      class: 'bg-blue-50 text-blue-700 dark:bg-blue-950/70 dark:text-blue-300 border border-blue-200 dark:border-blue-800',
    },
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header and Subtitle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <CalendarDays className="w-6 h-6 text-blue-600 dark:text-cyan-400" />
            <span>Smart Timetable & Automatic Schedule</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Connected institutional master timetable · Single source of truth for daily classes & attendance
          </p>
        </div>

        {/* View Mode Tabs */}
        <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl shrink-0">
          <button
            onClick={() => setActiveTab('daily')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
              activeTab === 'daily'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Daily Timetable
          </button>
          <button
            onClick={() => setActiveTab('weekly')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
              activeTab === 'weekly'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Weekly Summary
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
              activeTab === 'history'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Class History
          </button>
          <button
            onClick={() => setActiveTab('subjects')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
              activeTab === 'subjects'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Subject Frequency
          </button>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* 1. DAILY TIMETABLE VIEW */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'daily' && (
        <div className="space-y-6">
          {/* Calendar Date Navigator Bar */}
          <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <button
                onClick={() => shiftDate(-1)}
                className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
                title="Previous Day"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2">
                <input
                  type="date"
                  value={selectedDate}
                  onChange={e => setSelectedDate(e.target.value)}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                />
                <button
                  onClick={setDateToday}
                  className="px-3 py-2 rounded-xl text-xs font-semibold bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-cyan-300 hover:bg-blue-100 dark:hover:bg-blue-900/60 transition-colors"
                >
                  Today
                </button>
              </div>

              <button
                onClick={() => shiftDate(1)}
                className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
                title="Next Day"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Automatic Dynamic Class Calculation Banner */}
            <div className="flex items-center gap-3 text-right">
              <div className="text-right">
                <div className="text-sm font-extrabold text-slate-900 dark:text-white">
                  {schedule.dayName}, {schedule.dateFormatted.split(',')[1]}
                </div>
                <div className="text-xs font-semibold text-blue-600 dark:text-cyan-400">
                  {schedule.isHoliday ? (
                    <span className="text-amber-600 dark:text-amber-400">
                      {schedule.holidayInfo?.name} (Classes: 0)
                    </span>
                  ) : (
                    <span>
                      Automatic count: <strong>{schedule.totalClasses} classes scheduled</strong>
                    </span>
                  )}
                </div>
              </div>

              <div className="px-3.5 py-2 rounded-xl bg-blue-600 text-white font-mono font-extrabold text-lg tabular-nums shadow-sm shrink-0">
                {schedule.totalClasses}
              </div>
            </div>
          </div>

          {/* Daily Schedule Table & Status Cards */}
          {schedule.isHoliday ? (
            <div className="p-12 text-center rounded-3xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40">
              <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-900/60 text-amber-700 dark:text-amber-300 flex items-center justify-center mx-auto mb-3">
                <CalendarIcon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                {schedule.holidayInfo?.name}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 max-w-md mx-auto mt-1">
                {schedule.holidayInfo?.description || 'College is closed for regular lectures on this date.'}
              </p>
              <div className="mt-4 inline-block px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-900/80 text-amber-800 dark:text-amber-200 text-xs font-semibold">
                Scheduled Classes: 0 · Does not impact attendance percentage
              </div>
            </div>
          ) : schedule.classes.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <p className="text-sm font-semibold text-slate-500">
                No classes scheduled for {schedule.dayName}.
              </p>
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50 dark:bg-slate-800/40">
                <div className="flex items-center gap-3">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    {schedule.dayName} Timetable
                  </h3>
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-blue-100 text-blue-700 dark:bg-blue-900/60 dark:text-blue-300">
                    {schedule.totalClasses} Classes
                  </span>
                </div>

                <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                  <span>Completed: <strong className="font-mono text-emerald-600 dark:text-emerald-400">{schedule.completedClasses}</strong></span>
                  <span>·</span>
                  <span>Ongoing: <strong className="font-mono text-amber-600 dark:text-amber-400">{schedule.ongoingClasses}</strong></span>
                  <span>·</span>
                  <span>Remaining: <strong className="font-mono text-blue-600 dark:text-blue-400">{schedule.remainingClasses}</strong></span>
                </div>
              </div>

              {/* Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-400 bg-slate-50/80 dark:bg-slate-850">
                      <th className="py-3 px-4">Time Slot</th>
                      <th className="py-3 px-4">Subject & Code</th>
                      <th className="py-3 px-4">Faculty</th>
                      <th className="py-3 px-4">Room & Building</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Attendance Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {schedule.classes.map(item => (
                      <tr
                        key={item.id}
                        className={`hover:bg-slate-50/70 dark:hover:bg-slate-800/50 transition-colors ${
                          item.status === 'Ongoing' ? 'bg-blue-50/30 dark:bg-blue-950/20' : ''
                        }`}
                      >
                        <td className="py-3.5 px-4 font-mono font-medium text-slate-900 dark:text-slate-200 whitespace-nowrap">
                          {item.startTime} – {item.endTime}
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                            {item.subjectName}
                            {item.isSpecial && (
                              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300">
                                Special Class
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] font-mono text-slate-400">
                            {item.subjectCode} · {item.type.toUpperCase()}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                          {item.facultyName}
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="font-medium text-slate-800 dark:text-slate-200 block">
                            {item.room}
                          </span>
                          <span className="text-[11px] text-slate-400">
                            {item.building}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${statusBadges[item.status].class}`}>
                            {statusBadges[item.status].label}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => markClassAttendance(selectedDate, item.id, 'present')}
                              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors flex items-center gap-1 ${
                                item.attendanceStatus === 'present'
                                  ? 'bg-emerald-600 text-white shadow-sm'
                                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-emerald-950 hover:text-emerald-700'
                              }`}
                              title="Mark Present"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Present</span>
                            </button>
                            <button
                              onClick={() => markClassAttendance(selectedDate, item.id, 'absent')}
                              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors flex items-center gap-1 ${
                                item.attendanceStatus === 'absent'
                                  ? 'bg-rose-600 text-white shadow-sm'
                                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-rose-50 dark:hover:bg-rose-950 hover:text-rose-700'
                              }`}
                              title="Mark Absent"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              <span>Missed</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 2. WEEKLY CLASS SUMMARY (DYNAMICALLY COMPUTED FROM DATABASE) */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'weekly' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  This Week
                </span>
                <h2 className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                  Weekly Class Load & Distribution
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Automatically computed by querying the weekly institutional database.
                </p>
              </div>

              <div className="flex items-center gap-4 bg-slate-50 dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                <div className="text-center px-2">
                  <span className="text-[10px] text-slate-400 block uppercase">Total Weekly</span>
                  <span className="text-xl font-extrabold font-mono text-blue-600 dark:text-cyan-400 tabular-nums">
                    {weeklySummary.totalWeeklyClasses} Classes
                  </span>
                </div>
                <div className="h-8 w-px bg-slate-200 dark:bg-slate-700" />
                <div className="text-center px-2">
                  <span className="text-[10px] text-slate-400 block uppercase">Average</span>
                  <span className="text-xl font-extrabold font-mono text-emerald-600 dark:text-emerald-400 tabular-nums">
                    {weeklySummary.averagePerDay} Classes/Day
                  </span>
                </div>
              </div>
            </div>

            {/* Weekly Days Breakdown Table */}
            <div className="mt-6 overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    <th className="py-3 px-4">Day of Week</th>
                    <th className="py-3 px-4 text-center">Classes Scheduled</th>
                    <th className="py-3 px-4">Load Visualization</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {weeklySummary.countsByDay.map(dayItem => (
                    <tr key={dayItem.day} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white">
                        {dayItem.day}
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono font-bold text-slate-800 dark:text-slate-200 tabular-nums text-sm">
                        {dayItem.count}
                      </td>
                      <td className="py-3.5 px-4 w-1/2">
                        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                          <div
                            className="bg-blue-600 h-full rounded-full transition-all"
                            style={{ width: `${(dayItem.count / 7) * 100}%` }}
                          />
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => {
                            // Find next date matching dayItem.dayIndex
                            const now = new Date();
                            const currentDay = now.getDay();
                            const diff = dayItem.dayIndex - currentDay;
                            now.setDate(now.getDate() + diff);
                            const y = now.getFullYear();
                            const m = String(now.getMonth() + 1).padStart(2, '0');
                            const d = String(now.getDate()).padStart(2, '0');
                            setSelectedDate(`${y}-${m}-${d}`);
                            setActiveTab('daily');
                          }}
                          className="text-xs font-semibold text-blue-600 dark:text-cyan-400 hover:underline"
                        >
                          Inspect Day →
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 3. CLASS HISTORY */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'history' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Class History
              </span>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                Past Dates Attendance Audit
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Audit for scheduled classes, attended classes, absent classes and day-wise attendance percentages.
              </p>
            </div>

            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {['2026-09-21', '2026-09-22', '2026-09-23', '2026-09-24', '2026-09-25', '2026-09-26'].map(dateStr => {
                const pastSched = getDateSchedule(dateStr);
                const attRecords = pastAttendance[dateStr] || {};
                const presentCount = Object.values(attRecords).filter(v => v === 'present').length;
                const absentCount = Object.values(attRecords).filter(v => v === 'absent').length;
                const marked = presentCount + absentCount;
                const pct = marked > 0 ? Math.round((presentCount / marked) * 100) : 100;

                return (
                  <div
                    key={dateStr}
                    onClick={() => {
                      setSelectedDate(dateStr);
                      setActiveTab('daily');
                    }}
                    className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:border-blue-300 dark:hover:border-blue-700 cursor-pointer transition-all"
                  >
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className="font-bold text-slate-900 dark:text-white">
                        {pastSched.dayName}, {dateStr.split('-').slice(1).join('/')}
                      </span>
                      <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                        {pct}%
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-center text-xs mt-3">
                      <div className="p-2 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                        <span className="text-[10px] text-slate-400 block">Scheduled</span>
                        <span className="font-mono font-bold">{pastSched.totalClasses}</span>
                      </div>
                      <div className="p-2 rounded bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-emerald-700 dark:text-emerald-300">
                        <span className="text-[10px] block">Attended</span>
                        <span className="font-mono font-bold">{presentCount}</span>
                      </div>
                      <div className="p-2 rounded bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300">
                        <span className="text-[10px] block">Missed</span>
                        <span className="font-mono font-bold">{absentCount}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 4. SUBJECT-WISE CLASS FREQUENCY */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'subjects' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                This Week · Subject Distribution
              </span>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                Subject-Wise Class Frequency
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Calculated directly from weekly timetable records for B.Tech Computer Science & Engineering.
              </p>
            </div>

            <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {subjectFrequency.map(sub => (
                <div
                  key={sub.subjectCode}
                  className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex items-center justify-between"
                >
                  <div>
                    <span className="text-[10px] font-mono font-semibold text-blue-600 dark:text-cyan-400">
                      {sub.subjectCode}
                    </span>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white mt-0.5">
                      {sub.subjectName}
                    </h4>
                  </div>
                  <div className="text-right">
                    <span className="text-2xl font-extrabold font-mono text-slate-800 dark:text-slate-100 tabular-nums">
                      {sub.count}
                    </span>
                    <span className="text-[10px] text-slate-400 block">Classes/Wk</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
