import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  AlertOctagon,
  PhoneCall,
  ShieldAlert,
  HeartPulse,
  Flame,
  Radio,
  X,
  CheckCircle2,
  MapPin,
} from 'lucide-react';

export const EmergencyModal: React.FC = () => {
  const { isEmergencyModalOpen, setEmergencyModalOpen, currentUser, addToast } = useApp();
  const [sosSent, setSosSent] = useState(false);
  const [selectedFacility, setSelectedFacility] = useState<string | null>(null);

  if (!isEmergencyModalOpen) return null;

  const contacts = [
    {
      title: 'Campus Security Control',
      number: '0120-2323-999',
      ext: 'Ext. 100',
      desc: '24x7 Main Gate Command & Proctorial Guard Dispatch',
      icon: <ShieldAlert className="w-5 h-5 text-rose-600 dark:text-rose-400" />,
      actionText: 'Call Security',
    },
    {
      title: 'Medical Health Center',
      number: '+91 98110 11108',
      ext: 'Ext. 108',
      desc: 'Resident Medical Officer, First-Aid & Emergency Ward',
      icon: <HeartPulse className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />,
      actionText: 'Call Doctor',
    },
    {
      title: 'Campus Ambulance Service',
      number: '102 / Ext. 102',
      ext: 'Ext. 102',
      desc: 'Rapid transfer to Kailash Hospital / Sharda Hospital Greater Noida',
      icon: <AlertOctagon className="w-5 h-5 text-amber-600 dark:text-amber-400" />,
      actionText: 'Request Ambulance',
    },
    {
      title: 'Fire Emergency Response',
      number: '101',
      ext: 'Ext. 101',
      desc: 'Greater Noida Knowledge Park Fire Station & Hydrant Unit',
      icon: <Flame className="w-5 h-5 text-red-600 dark:text-red-400" />,
      actionText: 'Fire Emergency',
    },
    {
      title: 'Women Safety & Anti-Harassment',
      number: '1090 / Ext. 145',
      ext: 'Ext. 145',
      desc: 'Confidential Internal Complaints Committee & Girls Hostel Warden',
      icon: <PhoneCall className="w-5 h-5 text-purple-600 dark:text-purple-400" />,
      actionText: 'Call Helpline',
    },
  ];

  const handleBroadcastSOS = () => {
    setSosSent(true);
    addToast({
      type: 'warning',
      title: '🚨 Emergency Distress Signal Broadcasted',
      description: `GPS coordinates & student beacon logged for ${currentUser?.name || 'Aarav Sharma'}. Campus Security dispatched.`,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-2xl border border-rose-200 dark:border-rose-900/50 shadow-2xl shadow-rose-900/20 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-rose-600 to-red-700 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-white/10 backdrop-blur-md">
              <AlertOctagon className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg font-bold">KCC ITM Emergency Center</h2>
              <p className="text-xs text-rose-100">
                Direct Priority Lines · Greater Noida Campus
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setEmergencyModalOpen(false);
              setSosSent(false);
            }}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Quick SOS Trigger Box */}
          <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-left">
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <Radio className="w-4 h-4 text-rose-600 dark:text-rose-400 animate-ping" />
                <span className="text-xs font-bold uppercase tracking-wider text-rose-700 dark:text-rose-300">
                  Instant Campus SOS Beacon
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300">
                Immediately transmits your location and student profile to Security Control & Medical Room.
              </p>
            </div>

            <button
              onClick={handleBroadcastSOS}
              disabled={sosSent}
              className={`w-full sm:w-auto px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all shadow-md shrink-0 flex items-center justify-center gap-2 ${
                sosSent
                  ? 'bg-emerald-600 text-white cursor-default'
                  : 'bg-rose-600 hover:bg-rose-700 text-white active:scale-95 shadow-rose-600/30'
              }`}
            >
              {sosSent ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  Beacon Active
                </>
              ) : (
                <>
                  <AlertOctagon className="w-4 h-4" />
                  Trigger SOS
                </>
              )}
            </button>
          </div>

          {sosSent && (
            <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2.5">
              <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                <strong>Distress Signal Logged:</strong> Location tag: Academic Block A, 2nd Floor (LH-201). Security mobile patrol notified.
              </span>
            </div>
          )}

          {/* Emergency Hotlines Directory */}
          <div className="space-y-2.5">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Direct Institutional Hotlines
            </h3>
            <div className="grid gap-2.5">
              {contacts.map((contact, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/60 dark:bg-slate-800/40 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shrink-0">
                      {contact.icon}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-semibold text-slate-900 dark:text-white">
                          {contact.title}
                        </h4>
                        <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                          {contact.ext}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {contact.desc}
                      </p>
                    </div>
                  </div>

                  <a
                    href={`tel:${contact.number.replace(/[^0-9+]/g, '')}`}
                    onClick={() => {
                      addToast({
                        type: 'info',
                        title: `Connecting to ${contact.title}`,
                        description: `Dialing ${contact.number}...`,
                      });
                    }}
                    className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 border border-slate-200 dark:border-slate-600 transition-colors shrink-0 flex items-center gap-1.5"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>{contact.number}</span>
                  </a>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <span>KCC ITM Campus Security Office · Knowledge Park III</span>
          <button
            onClick={() => setEmergencyModalOpen(false)}
            className="px-3 py-1 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
