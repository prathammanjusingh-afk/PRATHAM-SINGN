import React from 'react';

interface KccLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
}

export const KccLogo: React.FC<KccLogoProps> = ({
  className = '',
  size = 'md',
  showSubtitle = true,
}) => {
  const iconSizes = {
    sm: 'w-7 h-7 text-xs',
    md: 'w-9 h-9 text-sm',
    lg: 'w-12 h-12 text-base',
  };

  const titleSizes = {
    sm: 'text-sm font-bold',
    md: 'text-base font-bold',
    lg: 'text-xl font-extrabold',
  };

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* KCC ITM Vector Monogram Crest */}
      <div
        className={`${iconSizes[size]} relative flex items-center justify-center font-bold tracking-tight rounded-xl bg-gradient-to-br from-blue-700 via-indigo-700 to-slate-900 text-white shadow-md shadow-blue-900/20 border border-blue-400/30 shrink-0`}
      >
        <span className="font-extrabold tracking-tighter">KCC</span>
        <div className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-cyan-400 ring-2 ring-white dark:ring-slate-900" />
      </div>

      <div className="flex flex-col leading-tight">
        <span className={`${titleSizes[size]} tracking-tight text-slate-900 dark:text-white flex items-center gap-1.5`}>
          KCC ITM
          <span className="text-blue-600 dark:text-cyan-400 font-semibold text-xs tracking-normal px-1.5 py-0.5 bg-blue-50 dark:bg-blue-950/60 rounded border border-blue-200/60 dark:border-blue-800/40">
            SMART CAMPUS
          </span>
        </span>
        {showSubtitle && (
          <span className="text-[10px] font-medium text-slate-500 dark:text-slate-400 tracking-wide uppercase">
            Greater Noida · Uttar Pradesh
          </span>
        )}
      </div>
    </div>
  );
};
