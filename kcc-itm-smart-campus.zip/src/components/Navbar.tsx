import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { KccLogo } from './KccLogo';
import {
  Bell,
  Sun,
  Moon,
  AlertTriangle,
  ChevronDown,
  User,
  Shield,
  GraduationCap,
  LogOut,
  ExternalLink,
  Menu,
  X,
} from 'lucide-react';
import { UserRole } from '../types';

interface NavbarProps {
  onToggleMobileSidebar: () => void;
  isMobileSidebarOpen: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  onToggleMobileSidebar,
  isMobileSidebarOpen,
}) => {
  const {
    currentUser,
    activeRole,
    switchRole,
    logout,
    isDarkMode,
    toggleDarkMode,
    triggerSosBroadcast,
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    activeTab,
    setActiveTab,
  } = useApp();

  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);

  const unreadNotifs = notifications.filter(n => !n.read);

  const roles: { role: UserRole; label: string; icon: React.ReactNode; user: string }[] = [
    {
      role: 'student',
      label: 'Student View',
      icon: <GraduationCap className="w-4 h-4 text-blue-500" />,
      user: 'Aarav Sharma (B.Tech CSE)',
    },
    {
      role: 'admin',
      label: 'Administrator View',
      icon: <Shield className="w-4 h-4 text-rose-500" />,
      user: 'Prof. Rajiv Nandan (Dean)',
    },
    {
      role: 'faculty',
      label: 'Faculty View',
      icon: <User className="w-4 h-4 text-emerald-500" />,
      user: 'Dr. Priya Verma (HOD CSE)',
    },
  ];

  return (
    <header className="sticky top-0 z-30 h-16 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="h-full px-4 sm:px-6 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark (Single text element / logo mark) */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleMobileSidebar}
            className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 lg:hidden"
            aria-label="Toggle navigation menu"
          >
            {isMobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <button
            onClick={() => setActiveTab(currentUser ? 'dashboard' : 'landing')}
            className="text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-lg"
          >
            <KccLogo size="md" showSubtitle={false} />
          </button>
        </div>

        {/* Zone 2: 4-6 Clean text navigation links / Contextual items */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-600 dark:text-slate-300">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`hover:text-blue-600 dark:hover:text-cyan-400 transition-colors ${
              activeTab === 'dashboard' ? 'text-blue-600 dark:text-cyan-400 font-bold' : ''
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('timetable')}
            className={`hover:text-blue-600 dark:hover:text-cyan-400 transition-colors ${
              activeTab === 'timetable' ? 'text-blue-600 dark:text-cyan-400 font-bold' : ''
            }`}
          >
            Timetable
          </button>
          <button
            onClick={() => setActiveTab('attendance')}
            className={`hover:text-blue-600 dark:hover:text-cyan-400 transition-colors ${
              activeTab === 'attendance' ? 'text-blue-600 dark:text-cyan-400 font-bold' : ''
            }`}
          >
            Attendance
          </button>
          <button
            onClick={() => setActiveTab('map')}
            className={`hover:text-blue-600 dark:hover:text-cyan-400 transition-colors ${
              activeTab === 'map' ? 'text-blue-600 dark:text-cyan-400 font-bold' : ''
            }`}
          >
            Campus Map
          </button>
          <button
            onClick={() => setActiveTab('events')}
            className={`hover:text-blue-600 dark:hover:text-cyan-400 transition-colors ${
              activeTab === 'events' ? 'text-blue-600 dark:text-cyan-400 font-bold' : ''
            }`}
          >
            Events Hub
          </button>
          <button
            onClick={() => setActiveTab('complaints')}
            className={`hover:text-blue-600 dark:hover:text-cyan-400 transition-colors ${
              activeTab === 'complaints' ? 'text-blue-600 dark:text-cyan-400 font-bold' : ''
            }`}
          >
            Services
          </button>
        </nav>

        {/* Zone 3: 1-2 Primary Actions & Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Emergency SOS Quick Button */}
          <button
            onClick={triggerSosBroadcast}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-bold text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 dark:hover:bg-rose-900/50 border border-rose-200 dark:border-rose-900/60 transition-colors shrink-0 shadow-sm"
            title="Open Emergency Center"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-600 animate-pulse" />
            <span className="hidden sm:inline">EMERGENCY</span>
          </button>

          {/* Theme Toggle */}
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle theme"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              onClick={() => setNotifDropdownOpen(!notifDropdownOpen)}
              className="relative p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="View notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifs.length > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-blue-600 ring-2 ring-white dark:ring-slate-900" />
              )}
            </button>

            {notifDropdownOpen && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-4 py-3 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      Notifications
                    </span>
                    {unreadNotifs.length > 0 && (
                      <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 rounded-md">
                        {unreadNotifs.length} new
                      </span>
                    )}
                  </div>
                  {unreadNotifs.length > 0 && (
                    <button
                      onClick={markAllNotificationsRead}
                      className="text-[11px] text-blue-600 dark:text-cyan-400 hover:underline"
                    >
                      Mark all read
                    </button>
                  )}
                </div>

                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                  {notifications.length === 0 ? (
                    <div className="p-6 text-center text-xs text-slate-500">
                      No notifications at this time.
                    </div>
                  ) : (
                    notifications.map(notif => (
                      <div
                        key={notif.id}
                        onClick={() => {
                          markNotificationRead(notif.id);
                          if (notif.linkTab) setActiveTab(notif.linkTab);
                          setNotifDropdownOpen(false);
                        }}
                        className={`p-3.5 text-xs cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors flex items-start gap-2.5 ${
                          !notif.read ? 'bg-blue-50/40 dark:bg-blue-950/20' : ''
                        }`}
                      >
                        <div
                          className={`w-2 h-2 rounded-full mt-1 shrink-0 ${
                            !notif.read ? 'bg-blue-600' : 'bg-transparent'
                          }`}
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-slate-900 dark:text-white">
                            {notif.title}
                          </p>
                          <p className="text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2">
                            {notif.message}
                          </p>
                          <span className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 block">
                            {notif.timestamp}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile / Role Switcher */}
          {currentUser ? (
            <div className="relative">
              <button
                onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                className="flex items-center gap-2 p-1.5 pl-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-800/50 transition-colors text-left"
              >
                <div className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-xs uppercase shrink-0">
                  {currentUser.name.charAt(0)}
                </div>
                <div className="hidden lg:block leading-tight pr-1">
                  <div className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-[120px]">
                    {currentUser.name.split(' ')[0]}
                  </div>
                  <div className="text-[10px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    {currentUser.role}
                  </div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
              </button>

              {roleDropdownOpen && (
                <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="p-3.5 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800">
                    <p className="text-xs font-bold text-slate-900 dark:text-white">
                      {currentUser.name}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {currentUser.email}
                    </p>
                    <p className="text-[10px] font-mono text-blue-600 dark:text-cyan-400 mt-1">
                      {currentUser.studentId || currentUser.employeeId} · {currentUser.department}
                    </p>
                  </div>

                  <div className="p-2 space-y-1">
                    <p className="px-2 pt-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Switch Role (1-Click Demo)
                    </p>
                    {roles.map(r => (
                      <button
                        key={r.role}
                        onClick={() => {
                          switchRole(r.role);
                          setRoleDropdownOpen(false);
                        }}
                        className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs transition-colors ${
                          activeRole === r.role
                            ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 font-bold'
                            : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {r.icon}
                          <span>{r.label}</span>
                        </div>
                        {activeRole === r.role && (
                          <span className="text-[10px] font-semibold text-blue-600 dark:text-cyan-400">
                            Active
                          </span>
                        )}
                      </button>
                    ))}
                  </div>

                  <div className="p-2 border-t border-slate-200 dark:border-slate-800">
                    <button
                      onClick={() => {
                        logout();
                        setRoleDropdownOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors font-medium"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={() => setActiveTab('auth')}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 transition-colors shadow-sm"
            >
              Sign In
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
