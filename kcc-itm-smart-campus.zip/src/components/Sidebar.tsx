import React from 'react';
import { useApp } from '../context/AppContext';
import {
  LayoutDashboard,
  CalendarDays,
  CheckCheck,
  Bot,
  MapPin,
  Calendar,
  FileText,
  Wrench,
  Search,
  AlertTriangle,
  Zap,
  Shield,
  BookOpen,
  LogOut,
  ChevronRight,
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const {
    activeTab,
    setActiveTab,
    todaySchedule,
    overallAttendance,
    currentUser,
    activeRole,
    logout,
  } = useApp();

  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: <LayoutDashboard className="w-4 h-4" />,
      studentOnly: false,
    },
    {
      id: 'timetable',
      label: 'Smart Timetable',
      icon: <CalendarDays className="w-4 h-4" />,
      badge: `${todaySchedule.totalClasses} Today`,
      badgeColor: 'bg-blue-100 text-blue-700 dark:bg-blue-900/60 dark:text-blue-300',
    },
    {
      id: 'attendance',
      label: 'Smart Attendance',
      icon: <CheckCheck className="w-4 h-4" />,
      badge: `${overallAttendance.percentage}%`,
      badgeColor: overallAttendance.isSafe
        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/60 dark:text-emerald-300'
        : 'bg-amber-100 text-amber-700 dark:bg-amber-900/60 dark:text-amber-300',
    },
    {
      id: 'map',
      label: 'Digital Campus Map',
      icon: <MapPin className="w-4 h-4" />,
    },
    {
      id: 'events',
      label: 'Events Hub',
      icon: <Calendar className="w-4 h-4" />,
    },
    {
      id: 'assignments',
      label: 'Assignment Center',
      icon: <FileText className="w-4 h-4" />,
    },
    {
      id: 'complaints',
      label: 'Campus Services',
      icon: <Wrench className="w-4 h-4" />,
    },
    {
      id: 'lostfound',
      label: 'Lost & Found',
      icon: <Search className="w-4 h-4" />,
    },
    {
      id: 'emergency',
      label: 'Emergency Center',
      icon: <AlertTriangle className="w-4 h-4" />,
      badge: '24x7',
      badgeColor: 'bg-rose-100 text-rose-700 dark:bg-rose-900/60 dark:text-rose-300',
    },
    {
      id: 'intelligence',
      label: 'Campus Intelligence',
      icon: <Zap className="w-4 h-4" />,
    },
  ];

  // Admin section
  const adminItems = [
    {
      id: 'admin',
      label: 'Admin Control Hub',
      icon: <Shield className="w-4 h-4" />,
      badge: 'Admin',
      badgeColor: 'bg-purple-100 text-purple-700 dark:bg-purple-900/60 dark:text-purple-300',
    },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-950/50 backdrop-blur-sm lg:hidden transition-opacity"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed lg:sticky top-16 left-0 z-40 h-[calc(100vh-4rem)] w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col transition-transform duration-200 ease-in-out shrink-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Navigation list */}
        <div className="flex-1 px-3 py-4 overflow-y-auto space-y-6">
          <div>
            <div className="px-3 mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              Campus Operating System
            </div>
            <nav className="space-y-1">
              {navItems.map(item => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      onClose();
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
                      isActive
                        ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-cyan-300 shadow-sm border border-blue-200/50 dark:border-blue-900/40'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/70 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className={isActive ? 'text-blue-600 dark:text-cyan-400' : 'text-slate-400'}>
                        {item.icon}
                      </span>
                      <span>{item.label}</span>
                    </div>

                    {item.badge && (
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${item.badgeColor}`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Institutional Admin Suite */}
          <div>
            <div className="px-3 mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 flex items-center justify-between">
              <span>Administration</span>
              {activeRole !== 'admin' && (
                <span className="text-[9px] text-slate-400">(Switch role to test)</span>
              )}
            </div>
            <nav className="space-y-1">
              {adminItems.map(item => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      onClose();
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
                      isActive
                        ? 'bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 shadow-sm border border-purple-200/50 dark:border-purple-900/40'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/70 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className={isActive ? 'text-purple-600 dark:text-purple-400' : 'text-slate-400'}>
                        {item.icon}
                      </span>
                      <span>{item.label}</span>
                    </div>

                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${item.badgeColor}`}>
                      {item.badge}
                    </span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* User Card & Institution Footer */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/40 shrink-0">
          {currentUser ? (
            <div className="flex items-center justify-between p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-700 to-indigo-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                  {currentUser.name.charAt(0)}
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {currentUser.name}
                  </p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 capitalize">
                    {currentUser.role} · {currentUser.studentId || currentUser.employeeId}
                  </p>
                </div>
              </div>

              <button
                onClick={logout}
                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title="Sign out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setActiveTab('auth')}
              className="w-full py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors"
            >
              Sign In to Smart Campus
            </button>
          )}

          <div className="mt-2 text-center text-[10px] text-slate-400 dark:text-slate-500 font-medium">
            KCC ITM Greater Noida · v2026.1
          </div>
        </div>
      </aside>
    </>
  );
};
