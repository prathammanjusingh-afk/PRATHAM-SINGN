import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  UserProfile,
  UserRole,
  TimetableClass,
  SpecialClass,
  HolidayOrNoClass,
  DailyClassItem,
  SubjectAttendance,
  Assignment,
  CampusEvent,
  Complaint,
  LostFoundItem,
  Notice,
  NotificationItem,
  StudentRecord,
  CampusLocation,
} from '../types';
import {
  DEMO_USERS,
  INITIAL_TIMETABLE,
  INITIAL_SPECIAL_CLASSES,
  INITIAL_HOLIDAYS,
  INITIAL_SUBJECT_ATTENDANCE,
  INITIAL_PAST_ATTENDANCE,
  INITIAL_ASSIGNMENTS,
  INITIAL_EVENTS,
  INITIAL_COMPLAINTS,
  INITIAL_LOST_FOUND,
  CAMPUS_LOCATIONS,
  INITIAL_NOTICES,
  INITIAL_NOTIFICATIONS,
  DEMO_STUDENT_RECORDS,
} from '../data/mockData';

interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  description?: string;
}

interface AppContextType {
  // Auth
  currentUser: UserProfile | null;
  activeRole: UserRole;
  login: (emailOrId: string, pass: string) => boolean;
  logout: () => void;
  switchRole: (role: UserRole) => void;
  registerStudent: (data: Partial<UserProfile> & { password: string }) => boolean;
  
  // Theme
  isDarkMode: boolean;
  toggleDarkMode: () => void;

  // Timetable & Schedule Engine
  timetable: TimetableClass[];
  specialClasses: SpecialClass[];
  holidays: HolidayOrNoClass[];
  selectedDate: string; // YYYY-MM-DD
  setSelectedDate: (dateStr: string) => void;
  
  // Dynamic Calculations (Single Source of Truth)
  getDateSchedule: (dateStr: string) => {
    dayName: string;
    dateFormatted: string;
    isHoliday: boolean;
    holidayInfo?: HolidayOrNoClass;
    classes: DailyClassItem[];
    totalClasses: number;
    completedClasses: number;
    ongoingClasses: number;
    remainingClasses: number;
    attendedCount: number;
    absentCount: number;
    dailyAttendancePct: number | null;
  };
  todaySchedule: ReturnType<AppContextType['getDateSchedule']>;
  weeklySummary: {
    countsByDay: { day: string; count: number; dayIndex: number }[];
    totalWeeklyClasses: number;
    averagePerDay: number;
  };
  subjectFrequency: { subjectCode: string; subjectName: string; count: number }[];

  // Attendance
  pastAttendance: Record<string, Record<string, 'present' | 'absent'>>;
  markClassAttendance: (dateStr: string, classId: string, status: 'present' | 'absent') => void;
  overallAttendance: {
    totalClasses: number;
    presentCount: number;
    absentCount: number;
    percentage: number;
    requiredPercentage: number;
    isSafe: boolean;
  };
  subjectAttendanceList: SubjectAttendance[];
  calculateAttendanceTarget: (targetPct: number, currentPresent?: number, currentTotal?: number) => {
    neededConsecutive: number;
    canMiss: number;
    currentPct: number;
  };

  // Timetable Admin Actions
  addTimetableClass: (item: Omit<TimetableClass, 'id'>) => void;
  updateTimetableClass: (id: string, item: Partial<TimetableClass>) => void;
  deleteTimetableClass: (id: string) => void;
  addSpecialClass: (item: Omit<SpecialClass, 'id'>) => void;
  deleteSpecialClass: (id: string) => void;
  addHoliday: (item: Omit<HolidayOrNoClass, 'id'>) => void;
  deleteHoliday: (id: string) => void;

  // Assignments
  assignments: Assignment[];
  submitAssignment: (id: string, fileName: string) => void;

  // Events
  events: CampusEvent[];
  registerForEvent: (eventId: string) => void;
  unregisterFromEvent: (eventId: string) => void;

  // Complaints
  complaints: Complaint[];
  submitComplaint: (data: {
    category: Complaint['category'];
    title: string;
    description: string;
    location: string;
    priority: Complaint['priority'];
    department: string;
  }) => Promise<Complaint>;
  updateComplaintStatus: (id: string, status: Complaint['status'], note?: string, assignedTo?: string) => void;

  // Lost & Found
  lostFoundItems: LostFoundItem[];
  reportLostFound: (item: Omit<LostFoundItem, 'id' | 'reportedBy' | 'status'>) => void;
  markLostFoundClaimed: (id: string) => void;

  // Campus Locations & Directory
  campusLocations: CampusLocation[];
  selectedLocation: CampusLocation | null;
  setSelectedLocation: (loc: CampusLocation | null) => void;

  // Notices & Notifications
  notices: Notice[];
  addNotice: (notice: Omit<Notice, 'id' | 'publishedDate'>) => void;
  deleteNotice: (id: string) => void;
  notifications: NotificationItem[];
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;

  // Students (Admin)
  students: StudentRecord[];
  updateStudentStatus: (id: string, status: StudentRecord['status']) => void;

  // Emergency SOS
  isEmergencyModalOpen: boolean;
  setEmergencyModalOpen: (open: boolean) => void;
  triggerSosBroadcast: () => void;

  // Toast
  toasts: ToastMessage[];
  addToast: (toast: Omit<ToastMessage, 'id'>) => void;
  removeToast: (id: string) => void;

  // Active navigation tab
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY = 'kcc_itm_smart_campus_v1';

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Theme state
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('kcc_theme');
    return saved === 'dark';
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('kcc_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('kcc_theme', 'light');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode(prev => !prev);

  // Active User / Auth
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    // Default to Aarav Sharma student for immediate showcase, or from memory
    return DEMO_USERS['student@kccitm.demo'];
  });

  const activeRole: UserRole = currentUser?.role || 'student';

  // Navigation state
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Timetable data
  const [timetable, setTimetable] = useState<TimetableClass[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_timetable`);
    return saved ? JSON.parse(saved) : INITIAL_TIMETABLE;
  });

  const [specialClasses, setSpecialClasses] = useState<SpecialClass[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_special_classes`);
    return saved ? JSON.parse(saved) : INITIAL_SPECIAL_CLASSES;
  });

  const [holidays, setHolidays] = useState<HolidayOrNoClass[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_holidays`);
    return saved ? JSON.parse(saved) : INITIAL_HOLIDAYS;
  });

  // Current selected calendar date for timetable inspection (defaults to today's simulated date: 2026-09-26, or actual system date)
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    const now = new Date();
    // Use format YYYY-MM-DD
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  });

  // Attendance Records: { [dateStr]: { [classId]: 'present' | 'absent' } }
  const [pastAttendance, setPastAttendance] = useState<Record<string, Record<string, 'present' | 'absent'>>>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_past_attendance`);
    return saved ? JSON.parse(saved) : INITIAL_PAST_ATTENDANCE;
  });

  // Assignments
  const [assignments, setAssignments] = useState<Assignment[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_assignments`);
    return saved ? JSON.parse(saved) : INITIAL_ASSIGNMENTS;
  });

  // Events
  const [events, setEvents] = useState<CampusEvent[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_events`);
    return saved ? JSON.parse(saved) : INITIAL_EVENTS;
  });

  // Complaints
  const [complaints, setComplaints] = useState<Complaint[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_complaints`);
    return saved ? JSON.parse(saved) : INITIAL_COMPLAINTS;
  });

  // Lost & Found
  const [lostFoundItems, setLostFoundItems] = useState<LostFoundItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_lostfound`);
    return saved ? JSON.parse(saved) : INITIAL_LOST_FOUND;
  });

  // Notices
  const [notices, setNotices] = useState<Notice[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_notices`);
    return saved ? JSON.parse(saved) : INITIAL_NOTICES;
  });

  // Notifications
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_notifications`);
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  // Students (Admin)
  const [students, setStudents] = useState<StudentRecord[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_students`);
    return saved ? JSON.parse(saved) : DEMO_STUDENT_RECORDS;
  });

  // Selected Map Location
  const [selectedLocation, setSelectedLocation] = useState<CampusLocation | null>(null);

  // Emergency SOS Modal
  const [isEmergencyModalOpen, setEmergencyModalOpen] = useState<boolean>(false);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (toast: Omit<ToastMessage, 'id'>) => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;
    setToasts(prev => [...prev, { ...toast, id }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_timetable`, JSON.stringify(timetable));
  }, [timetable]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_special_classes`, JSON.stringify(specialClasses));
  }, [specialClasses]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_holidays`, JSON.stringify(holidays));
  }, [holidays]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_past_attendance`, JSON.stringify(pastAttendance));
  }, [pastAttendance]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_complaints`, JSON.stringify(complaints));
  }, [complaints]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_events`, JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_assignments`, JSON.stringify(assignments));
  }, [assignments]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_lostfound`, JSON.stringify(lostFoundItems));
  }, [lostFoundItems]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_notices`, JSON.stringify(notices));
  }, [notices]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_students`, JSON.stringify(students));
  }, [students]);

  // Auth Operations
  const login = (emailOrId: string, pass: string): boolean => {
    const clean = emailOrId.trim().toLowerCase();
    const foundUser = Object.values(DEMO_USERS).find(
      u => u.email.toLowerCase() === clean || (u.studentId && u.studentId.toLowerCase() === clean) || (u.employeeId && u.employeeId.toLowerCase() === clean)
    );

    if (foundUser && foundUser.password === pass) {
      setCurrentUser(foundUser);
      addToast({
        type: 'success',
        title: `Welcome, ${foundUser.name}`,
        description: `Signed in as ${foundUser.role.toUpperCase()} to KCC ITM Smart Campus.`,
      });
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    setActiveTab('landing');
    addToast({
      type: 'info',
      title: 'Signed Out',
      description: 'You have been safely disconnected from your campus session.',
    });
  };

  const switchRole = (role: UserRole) => {
    if (role === 'student') setCurrentUser(DEMO_USERS['student@kccitm.demo']);
    else if (role === 'admin') setCurrentUser(DEMO_USERS['admin@kccitm.demo']);
    else if (role === 'faculty') setCurrentUser(DEMO_USERS['faculty@kccitm.demo']);
    addToast({
      type: 'info',
      title: `Switched to ${role.toUpperCase()} View`,
      description: `Active role profile updated.`,
    });
  };

  const registerStudent = (data: Partial<UserProfile> & { password: string }): boolean => {
    const newStudent: UserProfile = {
      id: `usr_${Date.now()}`,
      name: data.name || 'New Student',
      email: data.email || 'student@kccitm.edu.in',
      role: 'student',
      studentId: data.studentId || `KCC2026CS${Math.floor(100 + Math.random() * 900)}`,
      department: data.department || 'Computer Science & Engineering',
      course: data.course || 'B.Tech CSE',
      year: data.year || '1st Year',
      semester: data.semester || '1st Semester',
      phone: data.phone || '+91 98000 00000',
    };
    setCurrentUser(newStudent);
    setActiveTab('dashboard');
    addToast({
      type: 'success',
      title: 'Registration Complete 🎉',
      description: `Welcome to KCC ITM Smart Campus, ${newStudent.name}!`,
    });
    return true;
  };

  // -------------------------------------------------------------
  // ⭐ CORE TIMETABLE & DATE-BASED CLASS CALCULATION ENGINE
  // -------------------------------------------------------------
  const getDateSchedule = (dateStr: string) => {
    // 1. Determine day of the week
    const [y, m, d] = dateStr.split('-').map(Number);
    const dateObj = new Date(y, m - 1, d);
    const dayOfWeek = dateObj.getDay(); // 0 = Sun, 1 = Mon, ..., 6 = Sat
    
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const dayName = dayNames[dayOfWeek];
    const dateFormatted = dateObj.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    });

    // 2. Check for holiday or no-class day
    const holidayFound = holidays.find(h => h.dateStr === dateStr);
    const isSunday = dayOfWeek === 0;

    if (holidayFound || isSunday) {
      return {
        dayName,
        dateFormatted,
        isHoliday: true,
        holidayInfo: holidayFound || {
          id: 'sun',
          dateStr,
          name: 'Sunday Campus Recess',
          type: 'no_classes' as const,
          description: 'Weekly campus weekend off. No academic lectures scheduled.',
        },
        classes: [],
        totalClasses: 0,
        completedClasses: 0,
        ongoingClasses: 0,
        remainingClasses: 0,
        attendedCount: 0,
        absentCount: 0,
        dailyAttendancePct: null,
      };
    }

    // 3. Retrieve weekly timetable for this dayOfWeek
    const scheduledRegular = timetable.filter(c => c.dayOfWeek === dayOfWeek);

    // 4. Retrieve special one-off classes for this date
    const specialsForDate = specialClasses.filter(s => s.dateStr === dateStr);

    // 5. Merge regular + special classes
    const combinedClasses: DailyClassItem[] = [
      ...scheduledRegular.map(r => ({
        id: r.id,
        isSpecial: false,
        subjectCode: r.subjectCode,
        subjectName: r.subjectName,
        facultyName: r.facultyName,
        room: r.room,
        building: r.building,
        startTime: r.startTime,
        endTime: r.endTime,
        type: r.type,
        status: 'Upcoming' as const,
      })),
      ...specialsForDate.map(s => ({
        id: s.id,
        isSpecial: true,
        subjectCode: s.subjectCode,
        subjectName: s.subjectName,
        facultyName: s.facultyName,
        room: s.room,
        building: s.building,
        startTime: s.startTime,
        endTime: s.endTime,
        type: s.type,
        status: 'Upcoming' as const,
      })),
    ];

    // Sort by startTime
    combinedClasses.sort((a, b) => a.startTime.localeCompare(b.startTime));

    // 6. Compute status (Completed / Ongoing / Upcoming) based on current clock time
    const now = new Date();
    const currentHours = now.getHours();
    const currentMinutes = now.getMinutes();
    const currentMinutesTotal = currentHours * 60 + currentMinutes;

    // Is the date being inspected TODAY?
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const isToday = dateStr === todayStr;

    let completed = 0;
    let ongoing = 0;
    let remaining = 0;

    const dateAttendance = pastAttendance[dateStr] || {};

    const evaluatedClasses = combinedClasses.map(item => {
      const [startH, startM] = item.startTime.split(':').map(Number);
      const [endH, endM] = item.endTime.split(':').map(Number);
      const startMinutesTotal = startH * 60 + startM;
      const endMinutesTotal = endH * 60 + endM;

      let status: 'Completed' | 'Ongoing' | 'Upcoming' = 'Upcoming';

      if (!isToday) {
        // If checking a date in past, all are completed; if in future, all upcoming
        if (dateStr < todayStr) status = 'Completed';
        else status = 'Upcoming';
      } else {
        if (currentMinutesTotal >= endMinutesTotal) {
          status = 'Completed';
        } else if (currentMinutesTotal >= startMinutesTotal && currentMinutesTotal < endMinutesTotal) {
          status = 'Ongoing';
        } else {
          status = 'Upcoming';
        }
      }

      if (status === 'Completed') completed++;
      else if (status === 'Ongoing') ongoing++;
      else remaining++;

      const attStatus = dateAttendance[item.id] || 'unmarked';

      return {
        ...item,
        status,
        attendanceStatus: attStatus as 'present' | 'absent' | 'unmarked',
      };
    });

    const attendedCount = evaluatedClasses.filter(c => c.attendanceStatus === 'present').length;
    const absentCount = evaluatedClasses.filter(c => c.attendanceStatus === 'absent').length;
    const markedTotal = attendedCount + absentCount;
    const dailyAttendancePct = markedTotal > 0 ? Math.round((attendedCount / markedTotal) * 1000) / 10 : null;

    return {
      dayName,
      dateFormatted,
      isHoliday: false,
      classes: evaluatedClasses,
      totalClasses: evaluatedClasses.length,
      completedClasses: completed,
      ongoingClasses: ongoing,
      remainingClasses: remaining,
      attendedCount,
      absentCount,
      dailyAttendancePct,
    };
  };

  // Today's schedule calculation
  const todayStr = useMemo(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  }, []);

  const todaySchedule = useMemo(() => getDateSchedule(todayStr), [todayStr, timetable, specialClasses, holidays, pastAttendance]);

  // Weekly Class Summary Calculation: Dynamically counted from Timetable Database
  const weeklySummary = useMemo(() => {
    const days = [
      { name: 'Monday', index: 1 },
      { name: 'Tuesday', index: 2 },
      { name: 'Wednesday', index: 3 },
      { name: 'Thursday', index: 4 },
      { name: 'Friday', index: 5 },
      { name: 'Saturday', index: 6 },
    ];

    const counts = days.map(d => {
      const count = timetable.filter(c => c.dayOfWeek === d.index).length;
      return { day: d.name, count, dayIndex: d.index };
    });

    const total = counts.reduce((acc, curr) => acc + curr.count, 0);
    const avg = counts.length > 0 ? Math.round((total / counts.length) * 10) / 10 : 0;

    return {
      countsByDay: counts,
      totalWeeklyClasses: total,
      averagePerDay: avg,
    };
  }, [timetable]);

  // Subject-wise class frequency dynamically computed from timetable records
  const subjectFrequency = useMemo(() => {
    const map: Record<string, { subjectCode: string; subjectName: string; count: number }> = {};
    timetable.forEach(c => {
      if (!map[c.subjectCode]) {
        map[c.subjectCode] = { subjectCode: c.subjectCode, subjectName: c.subjectName, count: 0 };
      }
      map[c.subjectCode].count += 1;
    });
    return Object.values(map).sort((a, b) => b.count - a.count);
  }, [timetable]);

  // Mark attendance for a single class on a date
  const markClassAttendance = (dateStr: string, classId: string, status: 'present' | 'absent') => {
    setPastAttendance(prev => ({
      ...prev,
      [dateStr]: {
        ...(prev[dateStr] || {}),
        [classId]: status,
      },
    }));
    addToast({
      type: 'success',
      title: 'Attendance Recorded',
      description: `Marked as ${status.toUpperCase()} for class ID ${classId} on ${dateStr}.`,
    });
  };

  // Overall Attendance Summary computed from Subject Attendance List
  const subjectAttendanceList = useMemo(() => {
    return INITIAL_SUBJECT_ATTENDANCE.map(sub => {
      // Calculate Safe / Warning / Critical
      let status: 'Safe' | 'Warning' | 'Critical' = 'Safe';
      if (sub.percentage < 70) status = 'Critical';
      else if (sub.percentage < 75) status = 'Warning';
      return { ...sub, status };
    });
  }, []);

  const overallAttendance = useMemo(() => {
    const totalConducted = subjectAttendanceList.reduce((acc, s) => acc + s.totalConducted, 0);
    const totalPresent = subjectAttendanceList.reduce((acc, s) => acc + s.presentCount, 0);
    const totalAbsent = totalConducted - totalPresent;
    const percentage = totalConducted > 0 ? Math.round((totalPresent / totalConducted) * 1000) / 10 : 0;
    return {
      totalClasses: totalConducted,
      presentCount: totalPresent,
      absentCount: totalAbsent,
      percentage,
      requiredPercentage: 75.0,
      isSafe: percentage >= 75.0,
    };
  }, [subjectAttendanceList]);

  // Mathematical Attendance Target Calculator
  const calculateAttendanceTarget = (
    targetPct: number,
    currentPresent = overallAttendance.presentCount,
    currentTotal = overallAttendance.totalClasses
  ) => {
    const P = currentPresent;
    const T = currentTotal;
    const currentPct = T > 0 ? (P / T) * 100 : 0;

    let neededConsecutive = 0;
    let canMiss = 0;

    if (currentPct < targetPct) {
      // (P + x) / (T + x) >= target / 100
      // 100P + 100x >= target*T + target*x
      // x*(100 - target) >= target*T - 100*P
      // x = ceil((target*T - 100*P) / (100 - target))
      const numerator = targetPct * T - 100 * P;
      const denominator = 100 - targetPct;
      if (denominator > 0) {
        neededConsecutive = Math.max(0, Math.ceil(numerator / denominator));
      }
    } else {
      // P / (T + y) >= target / 100
      // 100P >= target*T + target*y
      // target*y <= 100P - target*T
      // y = floor((100*P - target*T) / target)
      if (targetPct > 0) {
        const numerator = 100 * P - targetPct * T;
        canMiss = Math.max(0, Math.floor(numerator / targetPct));
      }
    }

    return {
      neededConsecutive,
      canMiss,
      currentPct: Math.round(currentPct * 10) / 10,
    };
  };

  // Timetable Admin Actions
  const addTimetableClass = (item: Omit<TimetableClass, 'id'>) => {
    const id = `tt_custom_${Date.now()}`;
    setTimetable(prev => [...prev, { ...item, id }]);
    addToast({
      type: 'success',
      title: 'Class Added to Timetable',
      description: `${item.subjectName} added to schedule for day index ${item.dayOfWeek}.`,
    });
  };

  const updateTimetableClass = (id: string, item: Partial<TimetableClass>) => {
    setTimetable(prev => prev.map(c => (c.id === id ? { ...c, ...item } : c)));
    addToast({
      type: 'success',
      title: 'Timetable Updated',
      description: 'Changes have been propagated to all student schedules.',
    });
  };

  const deleteTimetableClass = (id: string) => {
    setTimetable(prev => prev.filter(c => c.id !== id));
    addToast({
      type: 'info',
      title: 'Class Removed',
      description: 'Class removed from weekly schedule.',
    });
  };

  const addSpecialClass = (item: Omit<SpecialClass, 'id'>) => {
    const id = `sp_${Date.now()}`;
    setSpecialClasses(prev => [...prev, { ...item, id }]);
    addToast({
      type: 'success',
      title: 'Special Class Scheduled',
      description: `${item.subjectName} scheduled for ${item.dateStr}.`,
    });
  };

  const deleteSpecialClass = (id: string) => {
    setSpecialClasses(prev => prev.filter(s => s.id !== id));
    addToast({
      type: 'info',
      title: 'Special Class Cancelled',
      description: 'The extra lecture was removed from the date schedule.',
    });
  };

  const addHoliday = (item: Omit<HolidayOrNoClass, 'id'>) => {
    const id = `hol_${Date.now()}`;
    setHolidays(prev => [...prev, { ...item, id }]);
    addToast({
      type: 'warning',
      title: 'Holiday / No-Class Marked',
      description: `${item.name} set for ${item.dateStr}. Classes = 0 for this day.`,
    });
  };

  const deleteHoliday = (id: string) => {
    setHolidays(prev => prev.filter(h => h.id !== id));
    addToast({
      type: 'info',
      title: 'Holiday Removed',
      description: 'Regular academic schedule restored for that date.',
    });
  };

  // Assignments
  const submitAssignment = (id: string, fileName: string) => {
    const now = new Date();
    const formatted = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    setAssignments(prev =>
      prev.map(a =>
        a.id === id
          ? {
              ...a,
              status: 'Submitted',
              submittedAt: formatted,
              fileName,
            }
          : a
      )
    );
    addToast({
      type: 'success',
      title: 'Assignment Uploaded Successfully',
      description: `File "${fileName}" submitted for review.`,
    });
  };

  // Events
  const registerForEvent = (eventId: string) => {
    if (!currentUser) return;
    setEvents(prev =>
      prev.map(evt => {
        if (evt.id === eventId) {
          if (evt.registeredUserIds.includes(currentUser.id)) return evt;
          return {
            ...evt,
            registeredUserIds: [...evt.registeredUserIds, currentUser.id],
          };
        }
        return evt;
      })
    );
    addToast({
      type: 'success',
      title: 'Registration Confirmed 🎫',
      description: 'Your digital campus event pass is generated and saved in your events tab.',
    });
  };

  const unregisterFromEvent = (eventId: string) => {
    if (!currentUser) return;
    setEvents(prev =>
      prev.map(evt => {
        if (evt.id === eventId) {
          return {
            ...evt,
            registeredUserIds: evt.registeredUserIds.filter(id => id !== currentUser.id),
          };
        }
        return evt;
      })
    );
    addToast({
      type: 'info',
      title: 'Registration Cancelled',
      description: 'Your seat was freed for other participants.',
    });
  };

  // Complaints & Grievances
  const submitComplaint = async (data: {
    category: Complaint['category'];
    title: string;
    description: string;
    location: string;
    priority: Complaint['priority'];
    department: string;
  }): Promise<Complaint> => {
    const randomSeq = Math.floor(1000 + Math.random() * 9000);
    const ticketId = `KCC-REQ-2026-${randomSeq}`;
    const now = new Date();
    const timestamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const newTicket: Complaint = {
      id: `cmp_${Date.now()}`,
      ticketId,
      category: data.category,
      title: data.title,
      description: data.description,
      location: data.location,
      priority: data.priority,
      status: 'Submitted',
      department: data.department,
      submittedBy: currentUser?.id || 'usr_guest',
      studentName: currentUser?.name || 'Aarav Sharma',
      submittedAt: timestamp,
      updates: [
        {
          timestamp,
          note: 'Complaint submitted by student and logged into Campus Maintenance System.',
          author: 'System Auto-Router',
          status: 'Submitted',
        },
      ],
    };

    setComplaints(prev => [newTicket, ...prev]);
    addToast({
      type: 'success',
      title: `Ticket Created: ${ticketId}`,
      description: `Routed to ${data.department} with ${data.priority} priority.`,
    });

    return newTicket;
  };

  const updateComplaintStatus = (
    id: string,
    status: Complaint['status'],
    note?: string,
    assignedTo?: string
  ) => {
    const now = new Date();
    const timestamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    setComplaints(prev =>
      prev.map(c => {
        if (c.id === id) {
          const newUpdate = {
            timestamp,
            note: note || `Status updated to ${status}.`,
            author: currentUser?.name || 'Administrator',
            status,
          };
          return {
            ...c,
            status,
            assignedTo: assignedTo || c.assignedTo,
            updates: [newUpdate, ...c.updates],
          };
        }
        return c;
      })
    );

    addToast({
      type: 'success',
      title: 'Complaint Status Updated',
      description: `Ticket status set to ${status}.`,
    });
  };

  // Lost & Found
  const reportLostFound = (item: Omit<LostFoundItem, 'id' | 'reportedBy' | 'status'>) => {
    const newItem: LostFoundItem = {
      ...item,
      id: `lf_${Date.now()}`,
      reportedBy: currentUser?.id || 'usr_guest',
      status: 'open',
    };
    setLostFoundItems(prev => [newItem, ...prev]);
    addToast({
      type: 'success',
      title: `${item.type === 'lost' ? 'Lost' : 'Found'} Item Broadcasted`,
      description: `Your listing "${item.title}" is now visible to the entire campus.`,
    });
  };

  const markLostFoundClaimed = (id: string) => {
    setLostFoundItems(prev =>
      prev.map(item => (item.id === id ? { ...item, status: 'claimed' } : item))
    );
    addToast({
      type: 'info',
      title: 'Item Marked as Claimed',
      description: 'The listing status has been updated to Claimed/Resolved.',
    });
  };

  // Notices
  const addNotice = (notice: Omit<Notice, 'id' | 'publishedDate'>) => {
    const now = new Date();
    const publishedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const newNotice: Notice = {
      ...notice,
      id: `ntc_${Date.now()}`,
      publishedDate,
    };
    setNotices(prev => [newNotice, ...prev]);
    addToast({
      type: 'success',
      title: 'Campus Notice Published',
      description: `Announcement "${notice.title.substring(0, 32)}..." is now live on student noticeboards.`,
    });
  };

  const deleteNotice = (id: string) => {
    setNotices(prev => prev.filter(n => n.id !== id));
    addToast({
      type: 'info',
      title: 'Notice Archived',
      description: 'The notice has been removed from public display.',
    });
  };

  // Notifications
  const markNotificationRead = (id: string) => {
    setNotifications(prev =>
      prev.map(n => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    addToast({
      type: 'info',
      title: 'All Caught Up',
      description: 'All notifications marked as read.',
    });
  };

  // Students (Admin)
  const updateStudentStatus = (id: string, status: StudentRecord['status']) => {
    setStudents(prev =>
      prev.map(s => (s.id === id ? { ...s, status } : s))
    );
    addToast({
      type: 'info',
      title: 'Student Status Updated',
      description: `Record status changed to ${status}.`,
    });
  };

  // Emergency SOS Broadcast
  const triggerSosBroadcast = () => {
    setEmergencyModalOpen(true);
    addToast({
      type: 'warning',
      title: 'Emergency Center Activated',
      description: 'Direct priority dialers for KCC Campus Security & Medical Center connected.',
    });
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        activeRole,
        login,
        logout,
        switchRole,
        registerStudent,
        isDarkMode,
        toggleDarkMode,
        timetable,
        specialClasses,
        holidays,
        selectedDate,
        setSelectedDate,
        getDateSchedule,
        todaySchedule,
        weeklySummary,
        subjectFrequency,
        pastAttendance,
        markClassAttendance,
        overallAttendance,
        subjectAttendanceList,
        calculateAttendanceTarget,
        addTimetableClass,
        updateTimetableClass,
        deleteTimetableClass,
        addSpecialClass,
        deleteSpecialClass,
        addHoliday,
        deleteHoliday,
        assignments,
        submitAssignment,
        events,
        registerForEvent,
        unregisterFromEvent,
        complaints,
        submitComplaint,
        updateComplaintStatus,
        lostFoundItems,
        reportLostFound,
        markLostFoundClaimed,
        campusLocations: CAMPUS_LOCATIONS,
        selectedLocation,
        setSelectedLocation,
        notices,
        addNotice,
        deleteNotice,
        notifications,
        markNotificationRead,
        markAllNotificationsRead,
        students,
        updateStudentStatus,
        isEmergencyModalOpen,
        setEmergencyModalOpen,
        triggerSosBroadcast,
        toasts,
        addToast,
        removeToast,
        activeTab,
        setActiveTab,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
