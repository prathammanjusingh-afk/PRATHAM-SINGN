export type UserRole = 'student' | 'faculty' | 'admin';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  studentId?: string;
  employeeId?: string;
  department: string;
  course?: string;
  year?: string;
  semester?: string;
  phone?: string;
  avatar?: string;
}

export type ClassType = 'lecture' | 'lab' | 'tutorial';
export type ClassStatus = 'Completed' | 'Ongoing' | 'Upcoming';

export interface TimetableClass {
  id: string;
  dayOfWeek: number; // 1 = Monday, 2 = Tuesday, ... 6 = Saturday
  subjectCode: string;
  subjectName: string;
  facultyName: string;
  room: string;
  building: string;
  startTime: string; // '09:00'
  endTime: string;   // '10:00'
  type: ClassType;
  department?: string;
  semester?: string;
}

export interface SpecialClass {
  id: string;
  dateStr: string; // 'YYYY-MM-DD'
  subjectCode: string;
  subjectName: string;
  facultyName: string;
  room: string;
  building: string;
  startTime: string;
  endTime: string;
  type: ClassType;
  reason: string;
}

export interface HolidayOrNoClass {
  id: string;
  dateStr: string; // 'YYYY-MM-DD'
  name: string;
  type: 'holiday' | 'college_closed' | 'examination' | 'campus_event' | 'no_classes';
  description: string;
}

export interface DailyClassItem {
  id: string;
  isSpecial?: boolean;
  subjectCode: string;
  subjectName: string;
  facultyName: string;
  room: string;
  building: string;
  startTime: string;
  endTime: string;
  type: ClassType;
  status: ClassStatus;
  attendanceStatus?: 'present' | 'absent' | 'unmarked';
}

export interface SubjectAttendance {
  id: string;
  code: string;
  name: string;
  faculty: string;
  totalConducted: number;
  presentCount: number;
  absentCount: number;
  percentage: number;
  status: 'Safe' | 'Warning' | 'Critical';
}

export interface Assignment {
  id: string;
  subjectCode: string;
  subjectName: string;
  facultyName: string;
  title: string;
  description: string;
  dueDate: string;
  status: 'Submitted' | 'Pending' | 'Overdue';
  submittedAt?: string;
  fileName?: string;
  grade?: string;
  totalMarks: number;
}

export interface CampusEvent {
  id: string;
  title: string;
  category: 'Technical' | 'Hackathons' | 'Workshops' | 'Cultural' | 'Sports' | 'Clubs' | 'Seminars' | 'Competitions';
  date: string;
  time: string;
  venue: string;
  organizer: string;
  description: string;
  registeredUserIds: string[];
  maxSeats: number;
  tag: string;
  accentColor: string;
}

export interface ComplaintUpdate {
  timestamp: string;
  note: string;
  author: string;
  status: 'Submitted' | 'Assigned' | 'In Progress' | 'Resolved';
}

export interface Complaint {
  id: string;
  ticketId: string; // e.g. KCC-REQ-2026-1042
  category: 'Hostel' | 'Mess' | 'Electricity' | 'Water' | 'Internet' | 'Classroom' | 'Laboratory' | 'Cleaning' | 'Security' | 'Maintenance';
  title: string;
  description: string;
  location: string;
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  status: 'Submitted' | 'Assigned' | 'In Progress' | 'Resolved';
  department: string;
  submittedBy: string;
  studentName: string;
  submittedAt: string;
  assignedTo?: string;
  resolutionNotes?: string;
  updates: ComplaintUpdate[];
}

export interface LostFoundItem {
  id: string;
  type: 'lost' | 'found';
  title: string;
  category: 'Electronics' | 'ID Cards & Docs' | 'Books & Stationery' | 'Accessories' | 'Keys & Wallets' | 'Clothing' | 'Other';
  location: string;
  date: string;
  description: string;
  contactName: string;
  contactPhone: string;
  status: 'open' | 'claimed' | 'resolved';
  reportedBy: string;
}

export interface CampusLocation {
  id: string;
  name: string;
  category: 'Academic' | 'Labs' | 'Library' | 'Hostel' | 'Cafeteria' | 'Sports' | 'Medical' | 'Admin' | 'Security';
  building: string;
  floor: string;
  description: string;
  openingHours: string;
  facilities: string[];
  contact: string;
  position: { x: number; y: number }; // percentage on map
  directions: string[];
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  category: 'Academic' | 'Examination' | 'Hostel' | 'Events' | 'General' | 'Emergency';
  priority: 'Normal' | 'High' | 'Urgent';
  publishedDate: string;
  publishedBy: string;
  attachments?: string[];
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  category: 'attendance' | 'assignment' | 'notice' | 'event' | 'timetable' | 'complaint' | 'emergency';
  timestamp: string;
  read: boolean;
  linkTab?: string;
}

export interface StudentRecord {
  id: string;
  name: string;
  studentId: string;
  email: string;
  department: string;
  course: string;
  year: string;
  semester: string;
  phone: string;
  attendancePercentage: number;
  status: 'Active' | 'On Leave' | 'Suspended';
}
