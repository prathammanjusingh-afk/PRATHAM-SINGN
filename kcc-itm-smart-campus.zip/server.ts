import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

app.use(express.json());

// Initialize Gemini client if API key is provided
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  aiClient = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Intelligent fallback logic if Gemini API call fails or key is missing
function generateInstitutionalFallback(userPrompt: string, studentContext: any) {
  const p = userPrompt.toLowerCase();
  
  if (p.includes('classes') || p.includes('schedule') || p.includes('today')) {
    const todayClasses = studentContext?.todayClasses || 5;
    const completed = studentContext?.completedClasses || 2;
    const remaining = todayClasses - completed;
    return `For today at KCC ITM, you have **${todayClasses} classes scheduled** (${completed} completed, ${remaining} remaining). Your next session is **Cloud Computing & Virtualization** in Lab 3 at 11:30 AM with Prof. Rajesh Sharma.`;
  }
  
  if (p.includes('attendance') || p.includes('percentage') || p.includes('attend')) {
    const overall = studentContext?.attendancePercentage || 82.4;
    return `Your current overall campus attendance is **${overall}%** (Present: 70 / Total: 85 classes). You are currently above the mandatory 75% threshold. You can miss up to 8 more classes without falling below 75%, or attend 15 consecutive classes to reach 85%.`;
  }

  if (p.includes('library') || p.includes('where is the library') || p.includes('book')) {
    return `The **Central Library** is situated on the 2nd and 3rd floors of Academic Block A. It features over 45,000 volumes, IEEE digital access terminals, and private group discussion rooms. Hours are Monday–Saturday: 8:00 AM – 9:00 PM.`;
  }

  if (p.includes('complaint') || p.includes('hostel') || p.includes('service')) {
    return `You can report hostel, mess, Wi-Fi, or electrical issues directly via the **Campus Services / Complaint System** in the sidebar. Our AI will automatically categorize your issue and route it with a tracking ID (e.g., KCC-REQ-2026-XXXX).`;
  }

  if (p.includes('event') || p.includes('fest') || p.includes('hackathon')) {
    return `Upcoming campus highlights this month include the **KCC HackXelerate 2026** (48-hr Hackathon, Oct 4–5 in Seminar Hall 1) and the **Robotics Workshop** (Oct 8). Visit the **Events Hub** to register and grab your entry pass!`;
  }

  if (p.includes('emergency') || p.includes('security') || p.includes('medical') || p.includes('doctor')) {
    return `**KCC ITM Emergency Services:**\n• Campus Security Control: Ext. 100 / 0120-2323-999\n• Medical Centre (Ground Floor, Admin Block): Ext. 108\n• 24x7 Campus Ambulance: Ext. 102\n• Chief Proctor Office: Ext. 104`;
  }

  return `Welcome to **KCC ITM Smart Campus**! I can help you check your timetable, calculate required attendance, find lecture halls or labs, report maintenance complaints, explore upcoming campus fests, or get emergency help. How can I assist you right now?`;
}

// 1. Campus AI Chatbot Endpoint
app.post('/api/ai/chat', async (req, res) => {
  try {
    const { prompt, studentContext, history = [] } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required.' });
    }

    if (aiClient && process.env.GEMINI_API_KEY) {
      try {
        const systemPrompt = `You are KCC CampusAI, the official institutional AI companion for KCC Institute of Technology and Management (Greater Noida, Uttar Pradesh).
You assist students, faculty, and administrators with timely academic, scheduling, attendance, campus navigation, services, events, and institutional guidance.

Current Student Context:
- Name: ${studentContext?.name || 'Aarav Sharma'}
- Roll Number: ${studentContext?.rollNo || 'KCC2024CS089'}
- Course & Department: ${studentContext?.course || 'B.Tech Computer Science & Engineering, 3rd Year'}
- Current Attendance: ${studentContext?.attendancePercentage || '82.4'}% (70 attended / 85 total)
- Today's Classes: ${studentContext?.todayClasses || 5} classes (${studentContext?.completedClasses || 2} completed, ${studentContext?.remainingClasses || 3} remaining)
- Next Class: Cloud Computing, 11:30 AM - 12:30 PM, Lab 3, Block B
- Key Campus Landmarks: Academic Block A, Academic Block B, Central Library (Block A, 2nd Fl), AI & Robotics Lab (Block B, 1st Fl), Cafeteria & Food Court, Medical Centre (Admin Ground Fl), Boys Hostel & Girls Hostel, Sports Arena.

Maintain a polite, helpful, academic, and technologically forward tone. Format your answers clearly with markdown bullet points when helpful. Keep answers concise, factual, and accurate to KCC ITM Greater Noida.`;

        const response = await aiClient.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            systemInstruction: systemPrompt,
          },
        });

        const reply = response.text || generateInstitutionalFallback(prompt, studentContext);
        return res.json({ reply });
      } catch (err: any) {
        console.warn('Gemini API call failed, falling back to local campus intelligence:', err?.message);
        const fallback = generateInstitutionalFallback(prompt, studentContext);
        return res.json({ reply: fallback });
      }
    } else {
      const fallback = generateInstitutionalFallback(prompt, studentContext);
      return res.json({ reply: fallback });
    }
  } catch (error: any) {
    console.error('Error in /api/ai/chat:', error);
    return res.status(500).json({ error: 'Failed to process AI chat request.' });
  }
});

// 2. Complaint AI Classification Endpoint
app.post('/api/ai/classify-complaint', async (req, res) => {
  try {
    const { title, description } = req.body;
    if (!description && !title) {
      return res.status(400).json({ error: 'Description or title is required.' });
    }

    const textToClassify = `${title || ''} ${description || ''}`.toLowerCase();

    // Default institutional heuristics
    let category = 'Maintenance';
    let priority = 'Medium';
    let department = 'Campus Facilities Directorate';

    if (textToClassify.includes('light') || textToClassify.includes('electricity') || textToClassify.includes('power') || textToClassify.includes('fan') || textToClassify.includes('ac') || textToClassify.includes('switch')) {
      category = 'Electricity';
      priority = textToClassify.includes('spark') || textToClassify.includes('smoke') || textToClassify.includes('shock') ? 'Urgent' : 'High';
      department = 'Electrical Maintenance Division';
    } else if (textToClassify.includes('wifi') || textToClassify.includes('internet') || textToClassify.includes('lan') || textToClassify.includes('network') || textToClassify.includes('portal') || textToClassify.includes('login')) {
      category = 'Internet';
      priority = 'High';
      department = 'Campus IT & Networks Cell';
    } else if (textToClassify.includes('water') || textToClassify.includes('leak') || textToClassify.includes('tap') || textToClassify.includes('plumb') || textToClassify.includes('washroom') || textToClassify.includes('toilet')) {
      category = 'Water';
      priority = textToClassify.includes('overflow') || textToClassify.includes('no water') ? 'High' : 'Medium';
      department = 'Civil & Plumbing Services';
    } else if (textToClassify.includes('hostel') || textToClassify.includes('room') || textToClassify.includes('bed') || textToClassify.includes('warden')) {
      category = 'Hostel';
      priority = 'Medium';
      department = 'Hostel Administration Office';
    } else if (textToClassify.includes('mess') || textToClassify.includes('food') || textToClassify.includes('canteen') || textToClassify.includes('meal')) {
      category = 'Mess';
      priority = 'High';
      department = 'Food & Mess Advisory Board';
    } else if (textToClassify.includes('lab') || textToClassify.includes('pc') || textToClassify.includes('computer') || textToClassify.includes('software')) {
      category = 'Laboratory';
      priority = 'Medium';
      department = 'Computing Labs In-Charge';
    } else if (textToClassify.includes('clean') || textToClassify.includes('trash') || textToClassify.includes('garbage') || textToClassify.includes('dust')) {
      category = 'Cleaning';
      priority = 'Low';
      department = 'Housekeeping & Sanitation Unit';
    } else if (textToClassify.includes('security') || textToClassify.includes('theft') || textToClassify.includes('threat') || textToClassify.includes('gate') || textToClassify.includes('id card')) {
      category = 'Security';
      priority = 'Urgent';
      department = 'Campus Security & Proctorial Board';
    }

    // Try Gemini classification if available for richer reasoning
    if (aiClient && process.env.GEMINI_API_KEY) {
      try {
        const prompt = `Analyze this student grievance at KCC ITM:
Title: ${title}
Description: ${description}

Respond with pure JSON only matching this schema:
{
  "category": "Hostel" | "Mess" | "Electricity" | "Water" | "Internet" | "Classroom" | "Laboratory" | "Cleaning" | "Security" | "Maintenance",
  "priority": "Low" | "Medium" | "High" | "Urgent",
  "department": "string",
  "reasoning": "brief 1 sentence reasoning"
}`;

        const geminiRes = await aiClient.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
          },
        });

        if (geminiRes.text) {
          const parsed = JSON.parse(geminiRes.text);
          return res.json({
            category: parsed.category || category,
            priority: parsed.priority || priority,
            department: parsed.department || department,
            reasoning: parsed.reasoning || 'Automatically classified by KCC CampusAI.',
          });
        }
      } catch (e) {
        // Fall back to rule-based classification
      }
    }

    return res.json({
      category,
      priority,
      department,
      reasoning: `Rule-matched based on reported keywords and institutional routing.`,
    });
  } catch (error: any) {
    console.error('Error in /api/ai/classify-complaint:', error);
    return res.status(500).json({ error: 'Failed to classify complaint.' });
  }
});

// Health endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    institution: 'KCC Institute of Technology and Management',
    platform: 'KCC ITM Smart Campus',
    version: '2026.1',
    serverTime: new Date().toISOString(),
  });
});

async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    // Dev mode with Vite
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
        port,
        host: '0.0.0.0',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`KCC ITM Smart Campus server listening at http://localhost:${port}`);
  });
}

startServer();
